﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for pservice
/// </summary>
public class pservice
{
	public pservice()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int epfid { get; set; }
    public double EPF { get; set; }
    public string AcademicYear { get; set; }




}