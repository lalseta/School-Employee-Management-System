﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


using System.Collections;
/// <summary>
/// Summary description for Attendance
/// </summary>
public class Attendance
{
    ClsDB dobj = new ClsDB();
    SqlConnection cn = new SqlConnection();
    SqlDataAdapter da = new SqlDataAdapter();
    DataSet ds = new DataSet();
    DataSet ds1 = new DataSet();

    public DataSet sele(string str1)
    {
        
        SqlDataAdapter da1 = new SqlDataAdapter(str1, cn);
        da1.Fill(ds1);
        return ds1;
    }




    public void GetAttbyPK(Int32 id)
    {
        dobj.SQLStatement = " Select * from tbl_Attendance where Id= " + id + "";

        DataTable dtCity = new DataTable();

        dtCity = dobj.ResultSet();
        if (dtCity != null)
        {
            this._Id = Convert.ToInt32(dtCity.Rows[0].ItemArray[0]);
            this._eid = Convert.ToInt32(dtCity.Rows[0].ItemArray[1]);
            this._adate = Convert.ToString(dtCity.Rows[0].ItemArray[2]);
            this._atype = Convert.ToString(dtCity.Rows[0].ItemArray[3]);

        }
    }
    
	public Attendance()
	{
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
    }

    #region Properties


    public int _Id { get; set; }
    public int _eid { get; set; }
    public string _adate { set; get; }
    public string _atype { get; set; }
   // public int _Sid { get; set; }

    #endregion Properties



    public DataTable GetAttList()
    {
        dobj.SQLStatement = " SELECT    tbl_Attendance.Id,tbl_EmpPrsnlDetail.UserName AS Expr1, tbl_Attendance.Date, tbl_Attendance.AttendanceType FROM            tbl_Attendance INNER JOIN    tbl_EmpPrsnlDetail ON tbl_Attendance.Eid = tbl_EmpPrsnlDetail.Eid ";
        return dobj.ResultSet();
    }

    public DataTable GetAttListUname( string uname)
    {
        dobj.SQLStatement = " SELECT    tbl_Attendance.Id,tbl_EmpPrsnlDetail.UserName AS Expr1, tbl_Attendance.Date, tbl_Attendance.AttendanceType FROM            tbl_Attendance INNER JOIN    tbl_EmpPrsnlDetail ON tbl_Attendance.Eid = tbl_EmpPrsnlDetail.Eid where tbl_EmpPrsnlDetail.UserName='"+uname+"'";
        return dobj.ResultSet();
    }

    public DataTable GetAttById(int eid)
    {
        dobj.SQLStatement = " SELECT tbl_Attendance.Id,  tbl_Attendance.Date, tbl_Attendance.AttendanceType FROM  tbl_Attendance where  tbl_Attendance.Eid = " + _eid;
        return dobj.ResultSet();
    }

    public int UpdateAttList()
    {
        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();


        arrParam.Add("@_Id");
        arrValue.Add(_Id);

        arrParam.Add("@_eid");
        arrValue.Add(_eid);

        arrParam.Add("@_adate");
        arrValue.Add(_adate);

        arrParam.Add("@_atype");
        arrValue.Add(_atype);


        return dobj.ExecuteScalarByProc(arrParam, arrValue, "dbo.SP_Upadate_Att");

    }

    public int insertAtt()
    {

        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@_eid");
        arrValue.Add(_eid);

        arrParam.Add("@_adate");
        arrValue.Add(_adate);

        arrParam.Add("@_atype");
        arrValue.Add(_atype);


        return dobj.ExecuteScalarByProc(arrParam, arrValue, "SP_insert_Att");


    }

    public void dropdown(string str, DropDownList dd1city)
    {

        SqlCommand cmd = new SqlCommand(str);
        SqlDataAdapter da = new SqlDataAdapter(str,cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cn.Close();
        dd1city.DataSource = ds;
        dd1city.DataTextField = ds.Tables[0].Columns[1].ColumnName;
        dd1city.DataValueField = ds.Tables[0].Columns[0].ColumnName;
        dd1city.DataBind();
        dd1city.Items.Insert(0, new ListItem("--SELECT--", "0"));

    }
    public DataTable FillGrid(string str, GridView gd)
    {
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        DataTable dt = new DataTable();
        da.Fill(dt);


        gd.DataSource = dt;
        gd.DataBind();
        return dt;
    }



}