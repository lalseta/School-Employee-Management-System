﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
/// <summary>
/// Summary description for StateCls
/// </summary>
public class StateCls
{
    ClsDB dbobj = new ClsDB();

	public StateCls()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int UpdateCountryList()
    {
        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@Country_name");
        arrValue.Add(_State_Name);


        arrParam.Add("@Country_id");
        arrValue.Add(_SID);


        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "dbo.SP_Update_Country");

    }
 

    public int DeleteCountryList()
    {
        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@Country_id");
        arrValue.Add(_SID);


        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "dbo.SP_Delete_Country");

    }
    #region Properties

    public string _State_Name { get; set; }
    public int _SID { get; set; }

    #endregion Properties


    public void GetCountrybyPK(Int32 id)
    {
        dbobj.SQLStatement = " Select * from tbl_State where StateId= " + id + "";

        DataTable dtCounty = new DataTable();

        dtCounty = dbobj.ResultSet();
        if (dtCounty != null)
        {

            this._State_Name = dtCounty.Rows[0].ItemArray[1].ToString();

        }
    }
  
    public DataTable GetCountryList()
    {

        dbobj.SQLStatement = " Select * from tbl_State  ";

        return dbobj.ResultSet();
    }

    public int insertCountry()
    {

        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@Country_name");
        arrValue.Add(_State_Name);



        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "SP_insert_co");


    }

}