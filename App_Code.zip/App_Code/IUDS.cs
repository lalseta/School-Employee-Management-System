﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for IUDS
/// </summary>
public class IUDS
{
    SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
	public IUDS()
	{
		//
		// TODO: Add constructor logic here
		//
       // cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
	}
    public string IncomeTax="";
    public void ins(string str)
    {
        cmd.CommandText = str;
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }

   

    public DataSet sel(string str)
    {
        ds=new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        da.Fill(ds);
        return ds;


    }
    public void dropdown(string str, DropDownList dd1city)
    {

        SqlCommand cmd = new SqlCommand(str);
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cn.Close();
        dd1city.DataSource = ds;
        dd1city.DataTextField = ds.Tables[0].Columns[1].ColumnName;
        dd1city.DataValueField = ds.Tables[0].Columns[0].ColumnName;
        dd1city.DataBind();
        dd1city.Items.Insert(0, new ListItem("--SELECT--", "0"));

    }
    public DataTable FillGrid(string str, GridView gd)
    {
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        DataTable dt = new DataTable();
        da.Fill(dt);

        gd.DataSource = dt;
        gd.DataBind();
        return dt;
    }


}



//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Data;
//using System.Data.Sql;
//using System.Data.SqlClient;
//using System.Collections;

//public partial class Default2 : System.Web.UI.Page
//{

//    SqlConnection cn = new SqlConnection();
//    SqlCommand cmd = new SqlCommand();
//    DataSet ds = new DataSet();
//    RealEstateManagement obj = new RealEstateManagement();

//    protected void Page_Load(object sender, EventArgs e)
//    {
//        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|REMS.mdf;Integrated Security=True;User Instance=True";
//        cn.Open();

//        if (!IsPostBack)
//        {

//            obj.grdfill("select * from tblCityMaster", GridView1);

//        }
//    }
//    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
//    {
//        int id = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);

//        cmd.CommandText = "delete from tblCityMaster where CityId=" + id + "";
//        cmd.Connection = cn;
//        cmd.ExecuteNonQuery();
//        cn.Close();
//        obj.grdfill("select * from tblCityMaster", GridView1);

//    }
//    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
//    {
//        GridView1.EditIndex = e.NewEditIndex;
//        int index = GridView1.EditIndex;
//        GridViewRow row = GridView1.Rows[index];
//        int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
//        obj.grdfill("select * from tblCityMaster", GridView1);
//    }
//    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
//    {
//        int index = GridView1.EditIndex;
//        GridViewRow row = GridView1.Rows[index];
//        int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
//        TextBox txtcntry = (TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0];

//        cmd = new SqlCommand();
//        cmd.CommandText = "update tblCityMaster set CityName = '" + txtcntry.Text + "' where CityId = '" + id + "'";
//        cmd.Connection = cn;
//        cmd.ExecuteNonQuery();

//        GridView1.EditIndex = -1;
//        obj.grdfill("select * from tblCityMaster", GridView1);
//    }
//}