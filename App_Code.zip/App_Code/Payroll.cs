﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for Payroll
/// </summary>
public class Payroll
{
    SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
  public  DataSet ds = new DataSet();
	public Payroll()
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
	}
    public DataSet sel(string str)
    {
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        da.Fill(ds);
        return ds;


    }
    public void ins(string str)
    {
        cmd.CommandText = str;
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }

}