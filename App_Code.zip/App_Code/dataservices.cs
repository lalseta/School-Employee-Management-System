﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for dataservices
/// </summary>
public class dataservices
{

    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    pservice p=new pservice();
   

	public dataservices()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable fillepf(pservice p)
    {
        cmd = new SqlCommand("getEPF", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public DataTable fillpt(pservice p)
    {
        cmd = new SqlCommand("getpt", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public DataTable fillda(pservice p)
    {
        cmd = new SqlCommand("getda", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public DataTable fillta(pservice p)
    {
        cmd = new SqlCommand("getta", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public void updategrid(pservice p)
    {
        cmd = new SqlCommand("updategrid", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@ID", p.epfid);
        cmd.Parameters.AddWithValue("@EPF", p.EPF);
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }





    public DataTable fillhra(pservice p)
    {
        cmd = new SqlCommand("gethra", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }



    public DataTable fillma(pservice p)
    {
        cmd = new SqlCommand("getma", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }



    public DataTable fillit(pservice p)
    {
        cmd = new SqlCommand("getit", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
}