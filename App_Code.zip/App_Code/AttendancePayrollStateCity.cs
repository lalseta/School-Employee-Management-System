﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for AttendancePayrollStateCity
/// </summary>
public class AttendancePayrollStateCity
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
    public AttendancePayrollStateCity()
    {

        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
        //
        // TODO: Add constructor logic here
        //
    }
    public void insrtsp(string str, SqlParameter[] param)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = str;

        cmd.ExecuteNonQuery();

    }
    public void dropdown(string str, DropDownList Ddl)
    {
        //    cn.Open();

        SqlCommand cmd = new SqlCommand(str);

        SqlDataAdapter da = new SqlDataAdapter(str, cn);

        DataSet ds = new DataSet();

        da.Fill(ds);

        cn.Close();

        Ddl.DataSource = ds;

        Ddl.DataTextField = ds.Tables[0].Columns[1].ColumnName;

        Ddl.DataValueField = ds.Tables[0].Columns[0].ColumnName;

        Ddl.DataBind();

        Ddl.Items.Insert(0, new ListItem("--Select--", "0"));

    }

}