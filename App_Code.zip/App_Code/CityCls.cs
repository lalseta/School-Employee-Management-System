﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

/// <summary>
/// Summary description for CityCls
/// </summary>
public class CityCls
{
    ClsDB dbobj = new ClsDB();
	public CityCls()
	{
		//
		// TODO: Add constructor logic here
		//
	}
      #region Properties


    public int _Cid { get; set; }
    public string _CityName { get; set; }
    public int _Sid { get; set; }
     
    #endregion Properties

    public int insertCity()
    {

        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@City_Name");
        arrValue.Add(_CityName);

        arrParam.Add("@Sid");
        arrValue.Add(_Sid);


        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "SP_insert_City");


    }
    public int UpdateCityList()
    {
        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@City_Name");
        arrValue.Add(_CityName);

        arrParam.Add("@City_id");
        arrValue.Add(_Cid);

        arrParam.Add("@State_id");
        arrValue.Add(_Sid);

   
        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "dbo.SP_Upadate_City");

    }
    public int DeleteCityList()
    {
        ArrayList arrParam = new ArrayList();
        ArrayList arrValue = new ArrayList();

        arrParam.Add("@City_id");
        arrValue.Add(_Cid);


        return dbobj.ExecuteScalarByProc(arrParam, arrValue, "dbo.SP_Delete_City");

    }
    public DataTable GetCityList()
    {
        dbobj.SQLStatement = " SELECT tbl_City.CityId, tbl_City.CityName, tbl_State.StateName FROM tbl_City INNER JOIN tbl_State ON tbl_City.StateId = tbl_State.StateId ";
        return dbobj.ResultSet();
    }

    public void GetCitybyPK(Int32 id)
    {
        dbobj.SQLStatement = " Select * from tbl_City where CityId= " + id + "";

        DataTable dtCity = new DataTable();

        dtCity = dbobj.ResultSet();
        if (dtCity != null)
        {
            this._Cid = Convert.ToInt32(dtCity.Rows[0].ItemArray[0]);
            this._CityName = dtCity.Rows[0].ItemArray[1].ToString();
            this._Sid = Convert.ToInt32(dtCity.Rows[0].ItemArray[2]);
            
        }
    }
}