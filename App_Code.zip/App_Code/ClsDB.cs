﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
/// <summary>
/// Summary description for ClsDB
/// </summary>
public class ClsDB
{
    public SqlConnection con = new SqlConnection();

    public ClsDB()
    {
        con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ToString();
    }

    public string SQLStatement
    { get; set; }


    public int UpdataQuery()
    {
        SqlCommand cmd = new SqlCommand(SQLStatement, con);

        int f = 0;
        if (con.State == ConnectionState.Closed)
            con.Open();
        f = cmd.ExecuteNonQuery();

        return f;
    }


    public DataSet ResultSet2()
    {
        try
        {
            SqlDataAdapter adp = new SqlDataAdapter(SQLStatement, con);
            DataSet dt = new DataSet();
            adp.Fill(dt);
            return dt;
        }
        catch (Exception ex)
        { throw ex; }
        finally { con.Close(); }
    }
    public DataTable ResultSet()
    {
        try
        {
            
            SqlDataAdapter adp = new SqlDataAdapter(SQLStatement, con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }
        catch (Exception ex)
        { throw ex; }
        finally { con.Close(); }
    }

    /*
        public int getLoginID(ArrayList arrParam, ArrayList arrValue, string SPName)
        {

            SqlCommand cmd = new SqlCommand();
            if (con.State == ConnectionState.Closed)
                con.Open();

            cmd.Connection = con;
            cmd.CommandText = SPName;
            cmd.CommandType = CommandType.StoredProcedure;

            if (arrParam != null)
            {
                for (int i = 0; i < arrParam.Count; i++)
                {
                    cmd.Parameters.AddWithValue(arrParam[i].ToString(), arrValue[i]);
                }
            }
            try
            {
                //int i=-1;
                // i=Convert.ToInt32(cmd.ExecuteScalar());
                // return  i;
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                   return sdr.GetInt16(1);       
               
                }
                else
                {
                    return 0;
                }


            }
            catch (Exception ex)
            {
                throw ex; //return 0;
            }
            finally
            {
                con.Close(); cmd.Dispose();
            }
        }
        */



    public int ExecuteScalarByProc(ArrayList arrParam, ArrayList arrValue, string SPName)
    {
        SqlCommand cmd = new SqlCommand();
        if (con.State == ConnectionState.Closed)
            con.Open();

        cmd.Connection = con;
        cmd.CommandText = SPName;
        cmd.CommandType = CommandType.StoredProcedure;

        if (arrParam != null)
        {
            for (int i = 0; i < arrParam.Count; i++)
            {
                cmd.Parameters.AddWithValue(arrParam[i].ToString(), arrValue[i]);
            }
        }
        try
        {
            //int i=-1;
            // i=Convert.ToInt32(cmd.ExecuteScalar());
            // return  i;
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.HasRows)
            {
                return 1;
            }
            else
            {
                return 0;
            }


        }
        catch (Exception ex)
        {
            throw ex; //return 0;
        }
        finally
        {
            con.Close(); cmd.Dispose();
        }
    }



}