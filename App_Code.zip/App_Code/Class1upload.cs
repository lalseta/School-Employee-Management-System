﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Class1upload
/// </summary>
public class Class1upload
{

    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();

	public Class1upload()
	{
		//
		// TODO: Add constructor logic here
		//
      
 cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
       cn.Open();
    }

    public DataSet ins(string str)
    {
        SqlDataAdapter da = new SqlDataAdapter(str, cn);
        da.Fill(ds);
     
        return ds;
    }
}