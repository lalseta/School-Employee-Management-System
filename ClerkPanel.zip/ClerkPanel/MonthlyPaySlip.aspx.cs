﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ClerkPanel_MonthlyPaySlip : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();

  public  DataSet ds1 = new DataSet();
  
   public DataSet ds3 = new DataSet();
    public DataSet ds4 = new DataSet();
   public DataSet ds5 = new DataSet();
   public DataSet ds6 = new DataSet();
   public DataSet ds7 = new DataSet();
   public DataSet ds8 = new DataSet();
   public DataSet ds9 = new DataSet();
   public DataSet ds10 = new DataSet();
   public IUDS aobj = new IUDS();

    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {

            SqlDataAdapter da = new SqlDataAdapter("SELECT [Eid], [UserName] FROM [tbl_EmpPrsnlDetail] WHERE (([DesignationId] <> 1) AND ([DesignationId] <> 6)) ORDER BY [Eid]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlEmpID.DataSource = ds;
            ddlEmpID.DataTextField = "UserName";
            ddlEmpID.DataValueField = "Eid";
            ddlEmpID.DataBind();
            ddlEmpID.Items.Insert(0, "-----Select-----");

        }

    }


    protected void ddlEmpID_SelectedIndexChanged(object sender, EventArgs e)
    {

    }




    protected void gendercalc()
    {
        string jenith = txtGender.Text.ToString();
        if (jenith == "m")
        {
            txtGender.Text = "Male";

        }
        else
        {
            txtGender.Text = "Female";
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // aobj.ins("insert into tbl_EmpMonthlySal(Username,Gender,Mobile,Post,BasicSalary,HRA,DA,MedicalAllowance,TravelingAllowance,TotalEarning,Other,EmployeeProvidentFund,ProfessionalTax,IncomeTax,TotalDeduction,NETSALARY,Name) values('"+ddlEmpID.SelectedItem.ToString()+"','"+txtEmployeeName+"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"','"++"',)");
    }

    protected void btnproceed_Click(object sender, EventArgs e)
    {
        ds1 = aobj.sel("select DISTINCT a.Eid, a.FirstName, a.MiddleName, a.Surname, a.JoiningDate,a.Email,a.Gender, a.DesignationId,a.ContactMob, b.DesignationName from tbl_EmpPrsnlDetail a join tbl_Designation b on a.DesignationId=b.DesignationId where Eid ='" + ddlEmpID.SelectedValue + "'");



        txtEmployeeName.Text = " " + ds1.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1.Tables[0].Rows[0]["Surname"].ToString();

        txtJoiningDate.Text = "" +Convert.ToDateTime( ds1.Tables[0].Rows[0]["JoiningDate"]).ToShortDateString();
        txtEmail.Text = "" + ds1.Tables[0].Rows[0]["Email"];
        txtGender.Text = "" + ds1.Tables[0].Rows[0]["Gender"].ToString();
        gendercalc();
        txtmobile.Text = "" + ds1.Tables[0].Rows[0]["ContactMob"].ToString();
        string designate = (string)ds1.Tables[0].Rows[0]["DesignationName"];
        txtPost.Text = designate;
        txtPost.Visible = true;
        //ds1.Clear();
       // DataSet ds2 = new DataSet();
        DataSet ds2 = new DataSet();
       ds2 = aobj.sel("select DISTINCT BasicSalary from tbl_BasicSalary where Eid ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "' ");
            txtBasicSal.Text = " " + ds2.Tables[0].Rows[0]["BasicSalary"].ToString();
            //// txtBasicSal.Text = "" + ds1.Tables[0].Rows[0]["BasicSalary"].ToString();

            ds2.Clear();
            ds2 = aobj.sel("select DISTINCT GradePay from tbl_BasicSalary where Eid ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "' ");
            txtGradePay.Text = " " + ds2.Tables[0].Rows[0]["GradePay"].ToString();
        



        ds3 = aobj.sel("select DISTINCT HRA from tbl_HRA where  AcademicYear='" + ddlyear2.SelectedValue + "' AND DesignationId='" + ds1.Tables[0].Rows[0]["DesignationId"] + "'");
        txtHRA.Text = "" + ds3.Tables[0].Rows[0]["HRA"].ToString();

        ds4 = aobj.sel("select DISTINCT DA from tbl_DA where AcademicYear='" + ddlyear2.SelectedValue + "'");
        txtDA.Text = "" + ds4.Tables[0].Rows[0]["DA"].ToString();
        // ds1.Clear();
        ds5 = aobj.sel("select DISTINCT MedicalAllowance from tbl_MedicalAllow where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
        txtMedicalAllow.Text = "" + ds5.Tables[0].Rows[0]["MedicalAllowance"].ToString();
        //ds1.Clear();
        ds6 = aobj.sel("select DISTINCT TravellingAllowance from tbl_TA where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
        txtTravellAllow.Text = "" + ds6.Tables[0].Rows[0]["TravellingAllowance"].ToString();
        //totalearning();
        // ds1.Clear();

        // ds1 = aobj.sel("select DISTINCT DA from tbl_DA where AcademicYear='" + ddlyear2.SelectedValue + "'");
        // txtProfessionFund.Text = "" + ds1.Tables[0].Rows[0]["DA"].ToString();
        // ds1.Clear();
        // ds1 = aobj.sel("select DISTINCT MedicalAllowance from tbl_MedicalAllow where DesignationId ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
        // txtProvidentFund.Text = "" + ds1.Tables[0].Rows[0]["MedicalAllowance"].ToString();
        // ds1.Clear();
        // ds1 = aobj.sel("select DISTINCT TravellingAllowance from tbl_TA where DesignationId ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
        // txtIncomeTax.Text = "" + ds1.Tables[0].Rows[0]["TravellingAllowance"].ToString();
        // ds1.Clear();

        // totalearning();
        // totaldeducting();

        // netsal();

        //  ds1 = aobj.sel("select DISTINCT DA from tbl_DA where Eid='"+ddlEmpID.SelectedValue+"'");

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        ddlyear2.SelectedIndex = 0;
        DDlMonth.SelectedIndex = 0;
        ddlEmpID.SelectedIndex = 0;
        txtEmployeeName.Text = "";
        txtJoiningDate.Text = "";
        txtEmail.Text = "";
        txtGender.Text = "";
        txtmobile.Text = "";
        txtPost.Text = "";
        txtBasicSal.Text = "";
        txtHRA.Text = "";
        txtDA.Text = "";
        txtMedicalAllow.Text = "";
        txtTravellAllow.Text = "";
        txtConveyancy.Text = "0";
        txtSpecialAllow.Text = "0";
        txtOther.Text = "0";
        txteffectivedays.Text = "0";
        txtTotalIncrement.Text = "";
        txtProvidentFund.Text = "";
        txtProfessionFund.Text = "";
        txtIncomeTax.Text = "";
        txtTotalDeduction.Text = "";
        txtNetSalary.Text = "";
    }


    //public void totalearning()
    //{
    //    double a = Convert.ToDouble(txtBasicSal.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text);
    //    txtTotalEarning.Text = a.ToString();
    //}
    //protected void totaldeducting()
    //{
    //    double a = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
    //    txtTotalDeduction.Text = a.ToString();
    //}
    //protected void netsal()
    //{
    //    double a = Convert.ToDouble(txtTotalEarning.Text) + Convert.ToDouble(txtTotalDeduction.Text);
    //    txtNetSalary.Text = a.ToString();
    //}

    ////protected void btnreset_Click(object sender, EventArgs e)
    ////{
    ////    ddlEmpID.SelectedIndex = 0;
    ////}
    //protected void btnreset_Click(object sender, EventArgs e)
    //{

   
   
   


    void professiontaxes()
    {
        double prft=Convert.ToDouble(txtBasicSal.Text);
        ds8 = aobj.sel("select * from tbl_ProfessionalTax where AcademicYear='"+ddlyear2.SelectedValue+"'");

        for (int i = 0; i<ds8.Tables[0].Rows.Count; i++ )
        {
           double lbl1 = Convert.ToDouble(ds8.Tables[0].Rows[i]["FromRs"]);
           double lbl2 = Convert.ToDouble(ds8.Tables[0].Rows[i]["ToRs"]);
           if (prft > lbl1 && prft < lbl2)
           {
               txtProfessionFund.Text = ds8.Tables[0].Rows[i]["TaxRs"].ToString();
                   return;
           }
        }
    
    }
    void incometaxes()
    {
        double prft1 = Convert.ToDouble(txtTotalEarning.Text);
        double yrlyprft=prft1 * 12;
        ds9 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");

        for (int i = 0; i < ds9.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds9.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds9.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds9.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtIncomeTax.Text = "0";
                    return;
                }
                else
                {
                    double taxesinperans = (yrlyprft / taxespinper);
                    double taxesinperansfinal = taxesinperans / 12;

                    txtIncomeTax.Text = taxesinperansfinal.ToString();
                    return;
                }
            }
        }
    }
    protected void txteffectivedays_TextChanged(object sender, EventArgs e)
    {
        if (txtConveyancy.Text == "")
        {
            txtConveyancy.Text = "0";
        }
        if (txtSpecialAllow.Text == "")
        {
            txtSpecialAllow.Text = "0";
        }
        if (txtOther.Text == "")
        {
            txtOther.Text = "0";
        }


        double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
        double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

        txtTotalEarning.Text = "";
        double a = effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
        txtTotalEarning.Text = a.ToString();
        double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
        txtTotalIncrement.Text = b.ToString();

        ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
        double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

        double ee = Convert.ToDouble(txtBasicSal.Text);
        double ansEPF = (ee * d) / 100;
        txtProvidentFund.Text = ansEPF.ToString();
        professiontaxes();
        incometaxes();
        double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
        txtTotalDeduction.Text = aa.ToString();
        double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
        txtNetSalary.Text = aaa.ToString();

    }
    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
       // aobj.ins("insert into tbl_EmpMonthlySal values() ")
    }
}
    