﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;





public partial class ClerkPanel_ViewOwnsPayroll : System.Web.UI.Page
{
    IUDS aobj = new IUDS();

    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void Btnprint_Click(object sender, EventArgs e)
    {
        Session["ctrl"] = Panel1;
        ClientScript.RegisterStartupScript(this.GetType(), "onclick", "<script language=javascript>window.open('Print.aspx','PrintMe','height=300px,width=300px,scrollbars=1');</script>");
        Response.Redirect("~/Print.aspx");
    }
    protected void DDlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

        try
        {

            string a = Session["new"].ToString();
            Panel1.Visible = true;
            DataSet ds1 = new DataSet();
            ds1 = aobj.sel("select * from tbl_EmpPrsnlDetail where UserName='" + a + "'");

            int abcd = Convert.ToInt16(ds1.Tables[0].Rows[0]["DesignationId"]);
            lblempname.Text = ((ds1.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1.Tables[0].Rows[0]["Surname"].ToString()).ToString());
            DateTime dob = (DateTime)ds1.Tables[0].Rows[0]["DateOfBirth"];
            int age = (int)Math.Floor((DateTime.Now - dob).TotalDays / 365.25D);
            lblage.Text = age.ToString();
            lbleid.Text = ds1.Tables[0].Rows[0]["Eid"].ToString();
            lblmobilenumber.Text = ds1.Tables[0].Rows[0]["ContactMob"].ToString();
            lblAccountNumber.Text = ds1.Tables[0].Rows[0]["AccountNumber"].ToString();
            lbldate.Text = System.DateTime.Now.ToShortDateString();
            lbldateofjoining.Text = Convert.ToDateTime(ds1.Tables[0].Rows[0]["JoiningDate"].ToString()).ToShortDateString();
            DataSet ds2 = new DataSet();
            //ds2 = aobj.sel("select  a.DesignationId,b.DesignationName from tbl_EmpPrsnlDetail a INNER JOIN tbl_Designation b on a.DesignationId=b.DesignationId where a.DesignationId=b.DesignationId");
            // string abc = Session["new"];

            ds2 = aobj.sel("select DesignationName from tbl_Designation where DesignationId=" + abcd);
            lbldesignation.Text = ds2.Tables[0].Rows[0]["DesignationName"].ToString();

            string asasasa = Session["new"].ToString();
            DataSet ds3 = new DataSet();
            ds3 = aobj.sel("select * from tbl_EmpMonthlySal where Username='" + asasasa + "' AND Month='" + DDlMonth.SelectedValue + "' ");

            if (ds3.Tables[0].Rows.Count > 0)
            {
                lblbasicSal.Text = ds3.Tables[0].Rows[0]["BasicSalary"].ToString();
                lblDA.Text = ds3.Tables[0].Rows[0]["DA"].ToString();
                lblMedicalAllowance.Text = ds3.Tables[0].Rows[0]["MedicalAllowance"].ToString();
                lblHRA.Text = ds3.Tables[0].Rows[0]["HRA"].ToString();
                lblTravelAllow.Text = ds3.Tables[0].Rows[0]["TravelingAllowance"].ToString();
                lblSpecialAllowance.Text = ds3.Tables[0].Rows[0]["SpecialAllowance"].ToString();
                lblgradepay.Text = ds3.Tables[0].Rows[0]["GradePay"].ToString();
                lblConveyance.Text = ds3.Tables[0].Rows[0]["Conveyance"].ToString();
                lblOther.Text = ds3.Tables[0].Rows[0]["Other"].ToString();
                lblGP.Text = ds3.Tables[0].Rows[0]["TotalEarning"].ToString();
                lblPF.Text = ds3.Tables[0].Rows[0]["EmployeeProvidentFund"].ToString();
                lblPTax.Text = ds3.Tables[0].Rows[0]["ProfessionalTax"].ToString();
                lblIncomeTax.Text = ds3.Tables[0].Rows[0]["IncomeTax"].ToString();
                lblDeduction.Text = ds3.Tables[0].Rows[0]["TotalDeductiion"].ToString();
                lbl.Text = ds3.Tables[0].Rows[0]["NETSALARY"].ToString();
                lbldays.Text = ds3.Tables[0].Rows[0]["EffectiveDays"].ToString();
            }
            else
            {
                //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('No SalarySlip for '"+DDlMonth.SelectedItem.Value.ToString()+"' '"+ddlyear2.SelectedItem.Value.ToString()+"' ');", true);
                System.Windows.Forms.MessageBox.Show("Enter Correct month Or Payslip for this month is not generated.");
                Panel1.Visible = false;
                return;

            }

        }
        catch (Exception)
        {

            System.Windows.Forms.MessageBox.Show("Please Select Year.. ");
            Response.Redirect("../Login.aspx");

        }


    }
}
