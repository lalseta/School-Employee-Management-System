﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class ClerkPanel_ManageCity : System.Web.UI.Page
{
    IUDS sobj = new IUDS(); 
    CityCls CityObj = new CityCls();
    ClsDB dbobj = new ClsDB();
    SqlConnection con;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection();

        con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ToString();

        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!IsPostBack)
        {
            FillCity();
            if (Request.QueryString["Id"] != null)
            {
                ViewState["Id"] = Request.QueryString["Id"];
                FillData();
                //fillStateDropDown();
                btnCSave.Text = "Update";

            }
            else
            {
        
                btnCSave.Text = "Save";

            }
        }


    }

    protected void FillData()
    {

        CityObj.GetCitybyPK(Convert.ToInt32(ViewState["Id"]));

        txt_city.Text = CityObj._CityName.ToString();
        s_dropdown1.SelectedValue = CityObj._Sid.ToString();
       

    }

    public void UpdateCity()
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
        cn.Open();

        SqlDataAdapter da = new SqlDataAdapter("select * from tbl_City where CityName = '" + txt_city.Text + "'", cn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count == 0)
        {
            //insertCountry();
            //FillCountry();
            CityObj._CityName = txt_city.Text;

            CityObj._Sid = Convert.ToInt32(ViewState["Id"]);

            ViewState["Id"] = CityObj.UpdateCityList();
            Label1.Visible = true;

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Already Successfully');", true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Update Successfully');", true);
        }

    }
    //{

    //    CityObj._CityName = txt_city.Text;
    //    CityObj._Cid = Convert.ToInt32(ViewState["Id"]);
     
    //    CityObj._Sid = Convert.ToInt32(s_dropdown1.SelectedValue);
    //    ViewState["Id"] = CityObj.UpdateCityList();

    //}

    void FillCity()
    {
        gv_city.DataSource = CityObj.GetCityList();
        gv_city.DataBind();
    }

    protected void gv_city_row_cmd(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "cmdEdit")
        {
            Response.Redirect("ManageCity.aspx?id=" + e.CommandArgument);

        }
        if (e.CommandName == "cmdDelete")
        {
            CityObj._Cid = Convert.ToInt32(e.CommandArgument);
            DeleteCity();

        }
    }
    public void DeleteCity()
    {

        ViewState["Id"] = CityObj.DeleteCityList();
        FillCity();
        //Response.Write("<script>alert('Deleted successfully');</script>");
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Deleted Successfully');", true);

    }
    protected void btnCSave_Click(object sender, EventArgs e)
    {
        if (ViewState["Id"] != null)
        {
            UpdateCity();
            FillCity();

            //Response.Write("<script>alert('Update Successfully')</script>");
           
            //lblmsg.Visible = true;
            //lblmsg.Text = "Update Successfully";
            txt_city.Text = "";
          
            s_dropdown1.SelectedIndex = 0;
            btnCSave.Text = "Save";

        }
        else
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from tbl_City where CityName = '" + txt_city.Text + "'", cn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                insertCity();
                FillCity();
            }

        }
        
    }

    void insertCity()
    {
        int abc = Convert.ToInt16(sobj.sel("select count(*) from tbl_state where Stateid='" + CityObj._Sid + "', CityName='" + CityObj._CityName + "'"));
        if (abc > 0)
        {
           // System.Console.Write("");
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Data is Repititive');", true);
        }
        else
        {
            CityObj._CityName = txt_city.Text;
            CityObj._Sid = Convert.ToInt32(s_dropdown1.SelectedValue);


            int r = 0;

            r = CityObj.insertCity();
            // Response.Write("<script>alert('Inserted Successfully')</script>");
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            txt_city.Text = "";
            s_dropdown1.SelectedIndex = 0;
            // c_dropdown1.SelectedIndex = 0;
        }
    }
}