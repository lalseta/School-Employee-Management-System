﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ClerkPanel_IncomeTax : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();


    IUDS aobj = new IUDS();
    protected void Page_Load(object sender, EventArgs e)
    {

        cn.Open();




        }





    
    protected void TextBox42_TextChanged(object sender, EventArgs e)
    {
        if (TextBox41.Text == "")
        {
            TextBox41.Text = "0";

        }
        if (TextBox42.Text == "")
        {
            TextBox42.Text = "0";

        }
        if (TextBox43.Text == "")
        {
            TextBox43.Text = "0";

        }
        if (TextBox44.Text == "")
        {
            TextBox44.Text = "0";

        }
        if (TextBox45.Text == "")
        {
            TextBox45.Text = "0";

        }
        if (TextBox46.Text == "")
        {
            TextBox46.Text = "0";

        }
        if (TextBox47.Text == "")
        {
            TextBox47.Text = "0";

        }
        if (TextBox48.Text == "")
        {
            TextBox48.Text = "0";

        }
        if (TextBox49.Text == "")
        {
            TextBox49.Text = "0";

        }
        if (TextBox50.Text == "")
        {
            TextBox50.Text = "0";

        }
        if (TextBox51.Text == "")
        {
            TextBox51.Text = "0";

        }
        if (TextBox52.Text == "")
        {
            TextBox52.Text = "0";

        }
        TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
        double totalinvest = Convert.ToDouble(TextBox53.Text);
        if (TextBox55.Text == "")
        {
            TextBox55.Text = "0";

        }
        TextBox56.Text = TextBox55.Text.ToString();
        double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

        if (asdf > 100000)
        {

            TextBox57.Text = Convert.ToString(asdf);
            double A = Convert.ToDouble(TextBox12.Text);//Gross
            double AA = (A * 12);

            double yrlyprft = AA - 100000;




            DataSet ds10 = new DataSet();

            ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
            for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
            {
                double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
                double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
                if (yrlyprft > lbl3 && yrlyprft < lbl4)
                {
                    double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                    if (taxespinper == 0)
                    {
                        txtincometaxperyear.Text = "";
                        txtincometaxpermonth.Text = "";
                        txtincometaxperyear.Text = "0";
                        txtincometaxpermonth.Text = "0";
                        return;
                    }
                    else
                    {
                        int taxesinperans = (Int32)(yrlyprft / taxespinper);
                        //   double taxesinperansfinal = taxesinperans / 12;
                        txtincometaxperyear.Text = "";
                        //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                        txtincometaxperyear.Text = taxesinperans.ToString();
                        int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                        txtincometaxpermonth.Text = "";
                        txtincometaxpermonth.Text = monthincometax.ToString();
                        aobj.IncomeTax = txtincometaxpermonth.Text;
                        return;
                    }
                }
            }

        }
        else
        {

            TextBox57.Text = Convert.ToString(asdf);
            double A = Convert.ToDouble(TextBox12.Text);//Gross
            double AA = (A * 12);

            double yrlyprft = AA - asdf;




            DataSet ds10 = new DataSet();

            ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
            for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
            {
                double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
                double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
                if (yrlyprft > lbl3 && yrlyprft < lbl4)
                {
                    double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                    if (taxespinper == 0)
                    {

                        txtincometaxperyear.Text = "";
                        txtincometaxpermonth.Text = "";
                        txtincometaxperyear.Text = "0";
                        txtincometaxpermonth.Text = "0";
                        return;
                    }
                    else
                    {
                        int taxesinperans = (Int32)(yrlyprft / taxespinper);
                        //   double taxesinperansfinal = taxesinperans / 12;
                        txtincometaxperyear.Text = "";
                        //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                        txtincometaxperyear.Text = taxesinperans.ToString();
                        int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                        txtincometaxpermonth.Text = "";
                        txtincometaxpermonth.Text = monthincometax.ToString();
                        aobj.IncomeTax = txtincometaxpermonth.Text;
                        return;
                    }
                }
            }



        }
    }
    protected void TextBox43_TextChanged(object sender, EventArgs e)
    {
        if (TextBox41.Text == "")
        {
            TextBox41.Text = "0";

        }
        if (TextBox42.Text == "")
        {
            TextBox42.Text = "0";

        }
        if (TextBox43.Text == "")
        {
            TextBox43.Text = "0";

        }
        if (TextBox44.Text == "")
        {
            TextBox44.Text = "0";

        }
        if (TextBox45.Text == "")
        {
            TextBox45.Text = "0";

        }
        if (TextBox46.Text == "")
        {
            TextBox46.Text = "0";

        }
        if (TextBox47.Text == "")
        {
            TextBox47.Text = "0";

        }
        if (TextBox48.Text == "")
        {
            TextBox48.Text = "0";

        }
        if (TextBox49.Text == "")
        {
            TextBox49.Text = "0";

        }
        if (TextBox50.Text == "")
        {
            TextBox50.Text = "0";

        }
        if (TextBox51.Text == "")
        {
            TextBox51.Text = "0";

        }
        if (TextBox52.Text == "")
        {
            TextBox52.Text = "0";

        }
        TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
        double totalinvest = Convert.ToDouble(TextBox53.Text);
        if (TextBox55.Text == "")
        {
            TextBox55.Text = "0";

        }
        TextBox56.Text = TextBox55.Text.ToString();
        double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

        if (asdf > 100000)
        {

            TextBox57.Text = Convert.ToString(asdf);
            double A = Convert.ToDouble(TextBox12.Text);//Gross
            double AA = (A * 12);

            double yrlyprft = AA - 100000;




            DataSet ds10 = new DataSet();

            ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
            for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
            {
                double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
                double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
                if (yrlyprft > lbl3 && yrlyprft < lbl4)
                {
                    double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                    if (taxespinper == 0)
                    {

                        txtincometaxperyear.Text = "";
                        txtincometaxpermonth.Text = "";
                        txtincometaxperyear.Text = "0";
                        txtincometaxpermonth.Text = "0";
                        return;
                    }
                    else
                    {
                        int taxesinperans = (Int32)(yrlyprft / taxespinper);
                        //   double taxesinperansfinal = taxesinperans / 12;
                        txtincometaxperyear.Text = "";
                        //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                        txtincometaxperyear.Text = taxesinperans.ToString();
                        int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                        txtincometaxpermonth.Text = "";
                        txtincometaxpermonth.Text = monthincometax.ToString();
                        aobj.IncomeTax = txtincometaxpermonth.Text;
                        return;
                    }
                }
            }

        }
        else
        {

            TextBox57.Text = Convert.ToString(asdf);
            double A = Convert.ToDouble(TextBox12.Text);//Gross
            double AA = (A * 12);

            double yrlyprft = AA - asdf;




            DataSet ds10 = new DataSet();

            ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
            for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
            {
                double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
                double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
                if (yrlyprft > lbl3 && yrlyprft < lbl4)
                {
                    double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                    if (taxespinper == 0)
                    {

                        txtincometaxperyear.Text = "";
                        txtincometaxpermonth.Text = "";
                        txtincometaxperyear.Text = "0";
                        txtincometaxpermonth.Text = "0";
                        return;
                    }
                    else
                    {
                        int taxesinperans = (Int32)(yrlyprft / taxespinper);
                        //   double taxesinperansfinal = taxesinperans / 12;
                        txtincometaxperyear.Text = "";
                        //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                        txtincometaxperyear.Text = taxesinperans.ToString();
                        int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                        txtincometaxpermonth.Text = "";
                        txtincometaxpermonth.Text = monthincometax.ToString();
                        aobj.IncomeTax = txtincometaxpermonth.Text;
                        return;
                    }
                }
            }



        }

    }
    protected void  TextBox44_TextChanged(object sender, EventArgs e)
{
    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }

    }
protected void  TextBox45_TextChanged(object sender, EventArgs e)
{
    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {

                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {

                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
}
protected void  TextBox46_TextChanged(object sender, EventArgs e)
{

    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
}
protected void  TextBox47_TextChanged(object sender, EventArgs e)
{

    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
}
protected void  TextBox48_TextChanged(object sender, EventArgs e)
{
    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {

                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {

                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }

}
protected void  TextBox49_TextChanged(object sender, EventArgs e)
{

    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
   
}
protected void  TextBox50_TextChanged(object sender, EventArgs e)
{
    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
}
protected void  TextBox51_TextChanged(object sender, EventArgs e)
{

    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }
}
protected void  TextBox52_TextChanged(object sender, EventArgs e)
{

    if (TextBox41.Text == "")
    {
        TextBox41.Text = "0";

    }
    if (TextBox42.Text == "")
    {
        TextBox42.Text = "0";

    }
    if (TextBox43.Text == "")
    {
        TextBox43.Text = "0";

    }
    if (TextBox44.Text == "")
    {
        TextBox44.Text = "0";

    }
    if (TextBox45.Text == "")
    {
        TextBox45.Text = "0";

    }
    if (TextBox46.Text == "")
    {
        TextBox46.Text = "0";

    }
    if (TextBox47.Text == "")
    {
        TextBox47.Text = "0";

    }
    if (TextBox48.Text == "")
    {
        TextBox48.Text = "0";

    }
    if (TextBox49.Text == "")
    {
        TextBox49.Text = "0";

    }
    if (TextBox50.Text == "")
    {
        TextBox50.Text = "0";

    }
    if (TextBox51.Text == "")
    {
        TextBox51.Text = "0";

    }
    if (TextBox52.Text == "")
    {
        TextBox52.Text = "0";

    }
    TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
    double totalinvest = Convert.ToDouble(TextBox53.Text);
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    if (asdf > 100000)
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - 100000;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }

    }
    else
    {

        TextBox57.Text = Convert.ToString(asdf);
        double A = Convert.ToDouble(TextBox12.Text);//Gross
        double AA = (A * 12);

        double yrlyprft = AA - asdf;




        DataSet ds10 = new DataSet();

        ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
        for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
        {
            double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
            double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
            if (yrlyprft > lbl3 && yrlyprft < lbl4)
            {
                double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                if (taxespinper == 0)
                {
                    txtincometaxperyear.Text = "";
                    txtincometaxpermonth.Text = "";
                 
                    txtincometaxperyear.Text = "0";
                    txtincometaxpermonth.Text = "0";
                    return;
                }
                else
                {
                    int taxesinperans = (Int32)(yrlyprft / taxespinper);
                    //   double taxesinperansfinal = taxesinperans / 12;
                    txtincometaxperyear.Text = "";
                    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                    txtincometaxperyear.Text = taxesinperans.ToString();
                    int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                    txtincometaxpermonth.Text = "";
                    txtincometaxpermonth.Text = monthincometax.ToString();
                    aobj.IncomeTax = txtincometaxpermonth.Text;
                    return;
                }
            }
        }



    }

}

protected void TextBox53_TextChanged(object sender, EventArgs e)
{
    
    
    double asdf=Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    TextBox57.Text =asdf.ToString() ;
    //double prft1 = Convert.ToDouble(txtTotalEarning.Text);
    //double yrlyprft = prft1 * 12;
    //ds9 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");

    //for (int i = 0; i < ds9.Tables[0].Rows.Count; i++)
    //{
    //    double lbl3 = Convert.ToDouble(ds9.Tables[0].Rows[i]["FromRs"]);
    //    double lbl4 = Convert.ToDouble(ds9.Tables[0].Rows[i]["ToRs"]);
    //    if (yrlyprft > lbl3 && yrlyprft < lbl4)
    //    {
    //        double taxespinper = Convert.ToDouble(ds9.Tables[0].Rows[i]["Taxinper"]);
    //        if (taxespinper == 0)
    //        {
    //            txtIncomeTax.Text = "0";
    //            return;
    //        }
    //        else
    //        {
    //            double taxesinperans = (yrlyprft / taxespinper);
    //            double taxesinperansfinal = taxesinperans / 12;

    //            txtIncomeTax.Text = taxesinperansfinal.ToString();
    //            return;
    //        }
    //    }
    //}









   // double AAA = Convert.ToDouble((A * 12));
   // txtincometaxperyear.Text = AA.ToString();
      
    
}

protected void txtincometaxpermonth_TextChanged(object sender, EventArgs e)
{

}
protected void btnsubmit_Click(object sender, EventArgs e)
{
    try
    {
        string a = Session["new"].ToString();

        DataSet ds1 = new DataSet();
        ds1 = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where UserName='" + a + "'");
        int b = Convert.ToInt16(ds1.Tables[0].Rows[0]["Eid"]);

        DataSet ds2 = new DataSet();
        ds2 = aobj.sel("select Eid from tbl_TDS where Eid ="+b+"");

        if (ds2.Tables[0].Rows.Count > 0)
        { //string a = Session["new"].ToString();

            ddlyear2.Enabled = false;
            TextBox1.ReadOnly = true;
            TextBox2.ReadOnly = true;
            TextBox3.ReadOnly = true;
            TextBox4.ReadOnly = true;
            TextBox5.ReadOnly = true;
            TextBox6.ReadOnly = true;
            TextBox7.ReadOnly = true;
            TextBox8.ReadOnly = true;
            TextBox9.ReadOnly = true;
            TextBox10.ReadOnly = true;
            TextBox11.ReadOnly = true;
            TextBox12.ReadOnly = true;
            TextBox13.ReadOnly = true;
            TextBox14.ReadOnly = true;
            TextBox15.ReadOnly = true;
            TextBox16.ReadOnly = true;
            TextBox17.ReadOnly = true;
            TextBox18.ReadOnly = true;
            TextBox19.ReadOnly = true;
            TextBox20.ReadOnly = true;
            TextBox21.ReadOnly = true;
            TextBox22.ReadOnly = true;
            TextBox23.ReadOnly = true;
            TextBox24.ReadOnly = true;
            TextBox25.ReadOnly = true;
            TextBox26.ReadOnly = true;
            TextBox27.ReadOnly = true;
            TextBox28.ReadOnly = true;
            TextBox29.ReadOnly = true;
            TextBox30.ReadOnly = true;
            TextBox31.ReadOnly = true;
            TextBox32.ReadOnly = true;
            TextBox33.ReadOnly = true;
            TextBox34.ReadOnly = true;
            TextBox35.ReadOnly = true;
            TextBox36.ReadOnly = true;
            TextBox38.ReadOnly = true;
            TextBox68.ReadOnly = true;
            TextBox39.ReadOnly = true;
            TextBox40.ReadOnly = true;
            TextBox41.ReadOnly = true;
            TextBox42.ReadOnly = true;
            TextBox43.ReadOnly = true;
            TextBox44.ReadOnly = true;
            TextBox45.ReadOnly = true;
            TextBox46.ReadOnly = true;
            TextBox47.ReadOnly = true;
            TextBox48.ReadOnly = true;
            TextBox49.ReadOnly = true;
            TextBox50.ReadOnly = true;
            TextBox51.ReadOnly = true;
            TextBox52.ReadOnly = true;
            TextBox53.ReadOnly = true;
            TextBox54.ReadOnly = true;
            TextBox55.ReadOnly = true;
            TextBox56.ReadOnly = true;
            TextBox57.ReadOnly = true;
            TextBox58.ReadOnly = true;
            TextBox60.ReadOnly = true;
            TextBox61.ReadOnly = true;
            TextBox62.ReadOnly = true;
            TextBox63.ReadOnly = true;
            TextBox64.ReadOnly = true;
            TextBox65.ReadOnly = true;
            TextBox66.ReadOnly = true;
            TextBox67.ReadOnly = true;
            txtincometaxperyear.ReadOnly = true;
            txtincometaxpermonth.ReadOnly = true;
            LblError.Text = "Do You Want to update '" + a + "'  Press Update Or Cancel Button";
            //    aobj.ins("update");
           // 
            btnsubmit.Visible = false;
            Btnupdate.Visible = true;
            BtnCancel.Visible = true;
        }
        else
        {


            string bb = Session["new"].ToString();

            DataSet ds11 = new DataSet();

            ds11 = aobj.sel("select Eid from tbl_EmpPrsnlDetail where UserName='" + bb + "'");
            string abc = ds11.Tables[0].Rows[0]["Eid"].ToString();
           
            int aa = Convert.ToInt16(abc);



            string str2 = "insert into tbl_TDS values(" + TextBox1.Text + "," + TextBox2.Text + "," + TextBox3.Text + "," + TextBox4.Text + "," + TextBox6.Text + "," + TextBox8.Text + "," + TextBox9.Text + "," + TextBox10.Text + "," + TextBox11.Text + "," + TextBox12.Text + "," + TextBox13.Text + "," + TextBox14.Text + "," + TextBox15.Text + "," + TextBox16.Text + "," + TextBox17.Text + "," + TextBox18.Text + "," + TextBox19.Text + "," + TextBox20.Text + "," + TextBox21.Text + "," + TextBox22.Text + "," + TextBox23.Text + "," + TextBox24.Text + "," + TextBox25.Text + "," + TextBox26.Text + "," + TextBox27.Text + "," + TextBox28.Text + "," + TextBox29.Text + "," + TextBox30.Text + "," + TextBox31.Text + "," + TextBox32.Text + "," + TextBox33.Text + "," + TextBox34.Text + "," + TextBox35.Text + "," + TextBox36.Text + "," + TextBox38.Text + "," + TextBox68.Text + "," + TextBox39.Text + "," + TextBox40.Text + "," + TextBox41.Text + "," + TextBox42.Text + "," + TextBox43.Text + "," + TextBox44.Text + "," + TextBox45.Text + "," + TextBox46.Text + "," + TextBox47.Text + "," + TextBox48.Text + "," + TextBox49.Text + "," + TextBox50.Text + "," + TextBox51.Text + "," + TextBox52.Text + "," + TextBox53.Text + "," + TextBox54.Text + "," + TextBox55.Text + "," + TextBox56.Text + "," + TextBox57.Text + "," + TextBox58.Text + "," + TextBox60.Text + "," + TextBox61.Text + "," + TextBox62.Text + "," + TextBox63.Text + "," + TextBox64.Text + "," + TextBox65.Text + "," + TextBox66.Text + "," + TextBox67.Text + "," + txtincometaxperyear.Text + "," + txtincometaxpermonth.Text + "," + ddlyear2.SelectedItem.Value + "," + aa + "," + TextBox5.Text + "," + TextBox7.Text + ")";
            aobj.ins(str2);
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
    }

    catch (Exception)
    {
        string a = Session["new"].ToString();

        System.Windows.Forms.MessageBox.Show("There is a Problem In Database Try again Later\"'"+a+"'\"");
    }
    
    //string a = Session["new"].ToString();

    //DataSet ds1 = new DataSet();
    //ds1 = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where UserName='" + a + "'");
    //int b = Convert.ToInt16(ds1.Tables[0].Rows[0]["Eid"]);
    //DataSet ds2 = new DataSet();
    //ds2 = aobj.sel("select * from tbl_EmpPrsnlDetail where Eid='" + b + "'");





    //if (ds2.Tables[0].Rows.Count > 0)
    //{
    //    try
    //    {
    //        cmd.Connection = cn;
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.CommandText = "TDSUpdate";
    //        cmd.Parameters.AddWithValue("@A1", TextBox1.Text);
    //        cmd.Parameters.AddWithValue("@A2", TextBox2.Text);
    //        cmd.Parameters.AddWithValue("@A3", TextBox3.Text);
    //        cmd.Parameters.AddWithValue("@A4", TextBox5.Text);
    //        cmd.Parameters.AddWithValue("@A5", TextBox6.Text);
    //        cmd.Parameters.AddWithValue("@A6", TextBox7.Text);
    //        cmd.Parameters.AddWithValue("@A7", TextBox8.Text);
    //        cmd.Parameters.AddWithValue("@A8", TextBox9.Text);
    //        cmd.Parameters.AddWithValue("@A9", TextBox10.Text);
    //        cmd.Parameters.AddWithValue("@A10", TextBox11.Text);
    //        cmd.Parameters.AddWithValue("@A11", TextBox2.Text);
    //        cmd.Parameters.AddWithValue("@B11", TextBox13.Text);
    //        cmd.Parameters.AddWithValue("@B111", TextBox14.Text);
    //        cmd.Parameters.AddWithValue("@B112", TextBox15.Text);
    //        cmd.Parameters.AddWithValue("@B12", TextBox16.Text);
    //        cmd.Parameters.AddWithValue("@B13", TextBox17.Text);
    //        cmd.Parameters.AddWithValue("@B14", TextBox18.Text);
    //        cmd.Parameters.AddWithValue("@B2", TextBox19.Text);
    //        cmd.Parameters.AddWithValue("@B3", TextBox20.Text);
    //        cmd.Parameters.AddWithValue("@B4", TextBox21.Text);
    //        cmd.Parameters.AddWithValue("@B5", TextBox22.Text);
    //        cmd.Parameters.AddWithValue("@B6", TextBox23.Text);
    //        cmd.Parameters.AddWithValue("@B7", TextBox24.Text);
    //        cmd.Parameters.AddWithValue("@C", TextBox25.Text);
    //        cmd.Parameters.AddWithValue("@D1", TextBox26.Text);
    //        cmd.Parameters.AddWithValue("@D2", TextBox27.Text);
    //        cmd.Parameters.AddWithValue("@D3", TextBox28.Text);
    //        cmd.Parameters.AddWithValue("@D4", TextBox29.Text);
    //        cmd.Parameters.AddWithValue("@D5", TextBox30.Text);
    //        cmd.Parameters.AddWithValue("@D6", TextBox31.Text);
    //        cmd.Parameters.AddWithValue("@D7", TextBox32.Text);
    //        cmd.Parameters.AddWithValue("@D8", TextBox33.Text);
    //        cmd.Parameters.AddWithValue("@E", TextBox34.Text);
    //        cmd.Parameters.AddWithValue("@F11", TextBox35.Text);
    //        cmd.Parameters.AddWithValue("@G11", TextBox36.Text);
    //        cmd.Parameters.AddWithValue("@H", TextBox38.Text);
    //        cmd.Parameters.AddWithValue("@I", TextBox68.Text);
    //        cmd.Parameters.AddWithValue("@I1", TextBox39.Text);
    //        cmd.Parameters.AddWithValue("@I2", TextBox40.Text);
    //        cmd.Parameters.AddWithValue("@J", TextBox41.Text);
    //        cmd.Parameters.AddWithValue("@K11", TextBox42.Text);
    //        cmd.Parameters.AddWithValue("@K2", TextBox43.Text);
    //        cmd.Parameters.AddWithValue("@K3", TextBox44.Text);
    //        cmd.Parameters.AddWithValue("@K4", TextBox45.Text);
    //        cmd.Parameters.AddWithValue("@K5", TextBox46.Text);
    //        cmd.Parameters.AddWithValue("@K6", TextBox47.Text);
    //        cmd.Parameters.AddWithValue("@K7", TextBox48.Text);
    //        cmd.Parameters.AddWithValue("@K8", TextBox49.Text);
    //        cmd.Parameters.AddWithValue("@K9", TextBox50.Text);
    //        cmd.Parameters.AddWithValue("@K10", TextBox51.Text);
    //        cmd.Parameters.AddWithValue("@K111", TextBox52.Text);
    //        cmd.Parameters.AddWithValue("@K12", TextBox53.Text);
    //        cmd.Parameters.AddWithValue("@L", TextBox54.Text);
    //        cmd.Parameters.AddWithValue("@L1", TextBox55.Text);
    //        cmd.Parameters.AddWithValue("@L2", TextBox56.Text);
    //        cmd.Parameters.AddWithValue("@M", TextBox57.Text);
    //        cmd.Parameters.AddWithValue("@N", TextBox58.Text);
    //        cmd.Parameters.AddWithValue("@O", TextBox69.Text);
    //        cmd.Parameters.AddWithValue("@O1", TextBox60.Text);
    //        cmd.Parameters.AddWithValue("@O11", TextBox61.Text);
    //        cmd.Parameters.AddWithValue("@O2", TextBox62.Text);
    //        cmd.Parameters.AddWithValue("@P", TextBox63.Text);
    //        cmd.Parameters.AddWithValue("@Q", TextBox64.Text);
    //        cmd.Parameters.AddWithValue("@R", TextBox65.Text);
    //        cmd.Parameters.AddWithValue("@R1", TextBox66.Text);
    //        cmd.Parameters.AddWithValue("@S", TextBox67.Text);
    //        cmd.Parameters.AddWithValue("@ITPyear", txtincometaxperyear.Text);
    //        cmd.Parameters.AddWithValue("@ITPmonth", txtincometaxpermonth.Text);
    //        cmd.Parameters.AddWithValue("@FinancialYear", ddlyear2.SelectedValue);
    //        cmd.Parameters.AddWithValue("@Eid ", b);

    //        cmd.ExecuteNonQuery();

    //        LblError.Text = Session["new"].ToString() + "'s Details Updated Successfully";
    //        LblError.Visible = true;


    //    }

    //    catch (Exception)
    //    {
    //        LblError.Visible = true;
    //        LblError.Text = "Please Enter correct Data or connection Lost";

    //    }
    //    finally
    //    {
    //        cn.Close();
    //    }


    //}
    //else
    //{
    //    try
    //    {

    //        cmd.Connection = cn;
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.CommandText = "TDS";
    //        cmd.Parameters.AddWithValue("@A1", TextBox1.Text);
    //        cmd.Parameters.AddWithValue("@A2", TextBox2.Text);
    //        cmd.Parameters.AddWithValue("@A3", TextBox3.Text);
    //        cmd.Parameters.AddWithValue("@A4", TextBox5.Text);
    //        cmd.Parameters.AddWithValue("@A5", TextBox6.Text);
    //        cmd.Parameters.AddWithValue("@A6", TextBox7.Text);
    //        cmd.Parameters.AddWithValue("@A7", TextBox8.Text);
    //        cmd.Parameters.AddWithValue("@A8", TextBox9.Text);
    //        cmd.Parameters.AddWithValue("@A9", TextBox10.Text);
    //        cmd.Parameters.AddWithValue("@A10", TextBox11.Text);
    //        cmd.Parameters.AddWithValue("@A11", TextBox2.Text);
    //        cmd.Parameters.AddWithValue("@B11", TextBox13.Text);
    //        cmd.Parameters.AddWithValue("@B111", TextBox14.Text);
    //        cmd.Parameters.AddWithValue("@B112", TextBox15.Text);
    //        cmd.Parameters.AddWithValue("@B12", TextBox16.Text);
    //        cmd.Parameters.AddWithValue("@B13", TextBox17.Text);
    //        cmd.Parameters.AddWithValue("@B14", TextBox18.Text);
    //        cmd.Parameters.AddWithValue("@B2", TextBox19.Text);
    //        cmd.Parameters.AddWithValue("@B3", TextBox20.Text);
    //        cmd.Parameters.AddWithValue("@B4", TextBox21.Text);
    //        cmd.Parameters.AddWithValue("@B5", TextBox22.Text);
    //        cmd.Parameters.AddWithValue("@B6", TextBox23.Text);
    //        cmd.Parameters.AddWithValue("@B7", TextBox24.Text);
    //        cmd.Parameters.AddWithValue("@C", TextBox25.Text);
    //        cmd.Parameters.AddWithValue("@D1", TextBox26.Text);
    //        cmd.Parameters.AddWithValue("@D2", TextBox27.Text);
    //        cmd.Parameters.AddWithValue("@D3", TextBox28.Text);
    //        cmd.Parameters.AddWithValue("@D4", TextBox29.Text);
    //        cmd.Parameters.AddWithValue("@D5", TextBox30.Text);
    //        cmd.Parameters.AddWithValue("@D6", TextBox31.Text);
    //        cmd.Parameters.AddWithValue("@D7", TextBox32.Text);
    //        cmd.Parameters.AddWithValue("@D8", TextBox33.Text);
    //        cmd.Parameters.AddWithValue("@E", TextBox34.Text);
    //        cmd.Parameters.AddWithValue("@F11", TextBox35.Text);
    //        cmd.Parameters.AddWithValue("@G11", TextBox36.Text);
    //        cmd.Parameters.AddWithValue("@H", TextBox38.Text);
    //        cmd.Parameters.AddWithValue("@I", TextBox68.Text);
    //        cmd.Parameters.AddWithValue("@I1", TextBox39.Text);
    //        cmd.Parameters.AddWithValue("@I2", TextBox40.Text);
    //        cmd.Parameters.AddWithValue("@J", TextBox41.Text);
    //        cmd.Parameters.AddWithValue("@K11", TextBox42.Text);
    //        cmd.Parameters.AddWithValue("@K2", TextBox43.Text);
    //        cmd.Parameters.AddWithValue("@K3", TextBox44.Text);
    //        cmd.Parameters.AddWithValue("@K4", TextBox45.Text);
    //        cmd.Parameters.AddWithValue("@K5", TextBox46.Text);
    //        cmd.Parameters.AddWithValue("@K6", TextBox47.Text);
    //        cmd.Parameters.AddWithValue("@K7", TextBox48.Text);
    //        cmd.Parameters.AddWithValue("@K8", TextBox49.Text);
    //        cmd.Parameters.AddWithValue("@K9", TextBox50.Text);
    //        cmd.Parameters.AddWithValue("@K10", TextBox51.Text);
    //        cmd.Parameters.AddWithValue("@K111", TextBox52.Text);
    //        cmd.Parameters.AddWithValue("@K12", TextBox53.Text);
    //        cmd.Parameters.AddWithValue("@L", TextBox54.Text);
    //        cmd.Parameters.AddWithValue("@L1", TextBox55.Text);
    //        cmd.Parameters.AddWithValue("@L2", TextBox56.Text);
    //        cmd.Parameters.AddWithValue("@M", TextBox57.Text);
    //        cmd.Parameters.AddWithValue("@N", TextBox58.Text);
    //        cmd.Parameters.AddWithValue("@O", TextBox69.Text);
    //        cmd.Parameters.AddWithValue("@O1", TextBox60.Text);
    //        cmd.Parameters.AddWithValue("@O11", TextBox61.Text);
    //        cmd.Parameters.AddWithValue("@O2", TextBox62.Text);
    //        cmd.Parameters.AddWithValue("@P", TextBox63.Text);
    //        cmd.Parameters.AddWithValue("@Q", TextBox64.Text);
    //        cmd.Parameters.AddWithValue("@R", TextBox65.Text);
    //        cmd.Parameters.AddWithValue("@R1", TextBox66.Text);
    //        cmd.Parameters.AddWithValue("@S", TextBox67.Text);
    //        cmd.Parameters.AddWithValue("@ITPyear", txtincometaxperyear.Text);
    //        cmd.Parameters.AddWithValue("@ITPmonth", txtincometaxpermonth.Text);
    //        cmd.Parameters.AddWithValue("@FinancialYear", ddlyear2.SelectedValue);
    //        cmd.Parameters.AddWithValue("@Eid ", b);

    //        cmd.ExecuteNonQuery();

    //        LblError.Text = Session["new"].ToString() + "'s Details Entered Successfully";
    //        LblError.Visible = true;


    //    }

    //    catch (Exception)
    //    {
    //        LblError.Visible = true;
    //        LblError.Text = "Please Enter correct Data or connection Lost";

    //    }
    //    finally
    //    {
    //        cn.Close();
    //    }
    //}
}
protected void ddlyear2_SelectedIndexChanged(object sender, EventArgs e)
{
    try
    {
        //string bongo = Session["new"].ToString();

        //DataSet jenith = new DataSet();
        //jenith = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where UserName='" +bongo + "'");
        //int ball = Convert.ToInt16(jenith.Tables[0].Rows[0]["Eid"]);

        //DataSet john = new DataSet();

        //john = aobj.sel("select * from tbl_TDS where Eid='" + ball + "'");
        //if (john.Tables[0].Rows.Count > 0)
        //{
        //    TextBox1.Text = "" + john.Tables[0].Rows[0]["A1"].ToString();
        //    TextBox2.Text = "" + john.Tables[0].Rows[0]["A2"].ToString();
        //    TextBox3.Text = "" + john.Tables[0].Rows[0]["A3"].ToString();
        //    TextBox4.Text = "" + john.Tables[0].Rows[0]["A4"].ToString();
        //    TextBox5.Text = "" + john.Tables[0].Rows[0]["A41"].ToString();
        //    TextBox6.Text = "" + john.Tables[0].Rows[0]["A5"].ToString();
        //    TextBox7.Text = "" + john.Tables[0].Rows[0]["A51"].ToString();
        //    TextBox8.Text = "" + john.Tables[0].Rows[0]["A6"].ToString();
        //    TextBox9.Text = "" + john.Tables[0].Rows[0]["A7"].ToString();
        //    TextBox10.Text = "" + john.Tables[0].Rows[0]["A8"].ToString();
        //    TextBox11.Text = "" + john.Tables[0].Rows[0]["A9"].ToString();
        //    TextBox12.Text = "" + john.Tables[0].Rows[0]["A10"].ToString();
        //    TextBox13.Text = "" + john.Tables[0].Rows[0]["B11"].ToString();
        //    TextBox14.Text = "" + john.Tables[0].Rows[0]["B111"].ToString();
        //    TextBox15.Text = "" + john.Tables[0].Rows[0]["B112"].ToString();
        //    TextBox16.Text = "" + john.Tables[0].Rows[0]["B12"].ToString();
        //    TextBox17.Text = "" + john.Tables[0].Rows[0]["B13"].ToString();
        //    TextBox18.Text = "" + john.Tables[0].Rows[0]["B14"].ToString();
        //    TextBox19.Text = "" + john.Tables[0].Rows[0]["B2"].ToString();
        //    TextBox20.Text = "" + john.Tables[0].Rows[0]["B3"].ToString();
        //    TextBox21.Text = "" + john.Tables[0].Rows[0]["B4"].ToString();
        //    TextBox22.Text = "" + john.Tables[0].Rows[0]["B5"].ToString();
        //    TextBox23.Text = "" + john.Tables[0].Rows[0]["B6"].ToString();
        //    TextBox24.Text = "" + john.Tables[0].Rows[0]["B7"].ToString();
        //    TextBox25.Text = "" + john.Tables[0].Rows[0]["C"].ToString();
        //    TextBox26.Text = "" + john.Tables[0].Rows[0]["D1"].ToString();
        //    TextBox27.Text = "" + john.Tables[0].Rows[0]["D2"].ToString();
        //    TextBox28.Text = "" + john.Tables[0].Rows[0]["D3"].ToString();
        //    TextBox29.Text = "" + john.Tables[0].Rows[0]["D4"].ToString();
        //    TextBox30.Text = "" + john.Tables[0].Rows[0]["D5"].ToString();
        //    TextBox31.Text = "" + john.Tables[0].Rows[0]["D6"].ToString();
        //    TextBox32.Text = "" + john.Tables[0].Rows[0]["D7"].ToString();
        //    TextBox33.Text = "" + john.Tables[0].Rows[0]["D8"].ToString();
        //    TextBox34.Text = "" + john.Tables[0].Rows[0]["E"].ToString();
        //    TextBox35.Text = "" + john.Tables[0].Rows[0]["F11"].ToString();
        //    TextBox36.Text = "" + john.Tables[0].Rows[0]["G11"].ToString();
        //    TextBox38.Text = "" + john.Tables[0].Rows[0]["H"].ToString();
        //    TextBox68.Text = "" + john.Tables[0].Rows[0]["I"].ToString();
        //    TextBox39.Text = "" + john.Tables[0].Rows[0]["I1"].ToString();
        //    TextBox40.Text = "" + john.Tables[0].Rows[0]["I2"].ToString();
        //    TextBox41.Text = "" + john.Tables[0].Rows[0]["J"].ToString();
        //    TextBox42.Text = "" + john.Tables[0].Rows[0]["K11"].ToString();
        //    TextBox43.Text = "" + john.Tables[0].Rows[0]["K2"].ToString();
        //    TextBox44.Text = "" + john.Tables[0].Rows[0]["K3"].ToString();
        //    TextBox45.Text = "" + john.Tables[0].Rows[0]["K4"].ToString();
        //    TextBox46.Text = "" + john.Tables[0].Rows[0]["K5"].ToString();
        //    TextBox47.Text = "" + john.Tables[0].Rows[0]["K6"].ToString();
        //    TextBox48.Text = "" + john.Tables[0].Rows[0]["K7"].ToString();
        //    TextBox49.Text = "" + john.Tables[0].Rows[0]["K8"].ToString();
        //    TextBox50.Text = "" + john.Tables[0].Rows[0]["K9"].ToString();
        //    TextBox51.Text = "" + john.Tables[0].Rows[0]["K10"].ToString();
        //    TextBox52.Text = "" + john.Tables[0].Rows[0]["K111"].ToString();
        //    TextBox53.Text = "" + john.Tables[0].Rows[0]["K12"].ToString();
        //    TextBox54.Text = "" + john.Tables[0].Rows[0]["L"].ToString();
        //    TextBox55.Text = "" + john.Tables[0].Rows[0]["L1"].ToString();
        //    TextBox56.Text = "" + john.Tables[0].Rows[0]["L2"].ToString();
        //    TextBox57.Text = "" + john.Tables[0].Rows[0]["M"].ToString();
        //    TextBox58.Text = "" + john.Tables[0].Rows[0]["N"].ToString();
        //    TextBox60.Text = "" + john.Tables[0].Rows[0]["O1"].ToString();
        //    TextBox61.Text = "" + john.Tables[0].Rows[0]["O11"].ToString();
        //    TextBox62.Text = "" + john.Tables[0].Rows[0]["O2"].ToString();
        //    TextBox63.Text = "" + john.Tables[0].Rows[0]["P"].ToString();
        //    TextBox64.Text = "" + john.Tables[0].Rows[0]["Q"].ToString();
        //    TextBox65.Text = "" + john.Tables[0].Rows[0]["R"].ToString();
        //    TextBox66.Text = "" + john.Tables[0].Rows[0]["R1"].ToString();
        //    TextBox67.Text = "" + john.Tables[0].Rows[0]["S"].ToString();
           


        //}
        //else
        //{





            string a = Session["new"].ToString();

            DataSet ds1 = new DataSet();
            ds1 = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where UserName='" + a + "'");
            int b = Convert.ToInt16(ds1.Tables[0].Rows[0]["Eid"]);
            DataSet ds2 = new DataSet();
            ds2 = aobj.sel("select DISTINCT BasicSalary, GradePay  from tbl_BasicSalary where Eid ='" + b + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'  ");


            DataSet ds3 = aobj.sel("Select DISTINCT DA from tbl_DA where  AcademicYear='" + ddlyear2.SelectedValue + "'");
            //double a11=Convert.ToDouble(ds3.Tables[0].Rows[0]["DA"];
            double da = Convert.ToDouble(Convert.ToDouble(ds2.Tables[0].Rows[0]["BasicSalary"]) + Convert.ToDouble(ds3.Tables[0].Rows[0]["DA"]));

            TextBox1.Text = (da + Convert.ToDouble(ds2.Tables[0].Rows[0]["GradePay"]) + da).ToString();
            DataSet ds4 = new DataSet();
            ds4 = aobj.sel("select DISTINCT HRA from tbl_HRA where  AcademicYear='" + ddlyear2.SelectedValue + "' AND DesignationId='" + ds1.Tables[0].Rows[0]["DesignationId"] + "'");

            TextBox2.Text = "" + (Convert.ToInt32(ds4.Tables[0].Rows[0]["HRA"])).ToString();

            DataSet ds5 = new DataSet();
            ds5 = aobj.sel("select DISTINCT MedicalAllowance from tbl_MedicalAllow where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            double asdfg = Convert.ToDouble(ds5.Tables[0].Rows[0]["MedicalAllowance"]) + 100 + 100;
            TextBox3.Text = "" + asdfg.ToString();

            DataSet ds6 = new DataSet();
            ds6 = aobj.sel("select DISTINCT TravellingAllowance from tbl_TA where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            TextBox8.Text = "" + ds6.Tables[0].Rows[0]["TravellingAllowance"].ToString();

            TextBox12.Text = (Convert.ToDouble(TextBox1.Text) + Convert.ToDouble(TextBox2.Text) + Convert.ToDouble(TextBox3.Text) + Convert.ToDouble(TextBox4.Text) + Convert.ToDouble(TextBox5.Text) + Convert.ToDouble(TextBox6.Text) + Convert.ToDouble(TextBox7.Text) + Convert.ToDouble(TextBox8.Text) + Convert.ToDouble(TextBox9.Text) + Convert.ToDouble(TextBox10.Text) + Convert.ToDouble(TextBox11.Text)).ToString();
            TextBox25.Text = TextBox12.Text.ToString();
            TextBox34.Text = TextBox25.Text.ToString();








            if (TextBox41.Text == "")
            {
                TextBox41.Text = "0";

            }
            if (TextBox42.Text == "")
            {
                TextBox42.Text = "0";

            }
            if (TextBox43.Text == "")
            {
                TextBox43.Text = "0";

            }
            if (TextBox44.Text == "")
            {
                TextBox44.Text = "0";

            }
            if (TextBox45.Text == "")
            {
                TextBox45.Text = "0";

            }
            if (TextBox46.Text == "")
            {
                TextBox46.Text = "0";

            }
            if (TextBox47.Text == "")
            {
                TextBox47.Text = "0";

            }
            if (TextBox48.Text == "")
            {
                TextBox48.Text = "0";

            }
            if (TextBox49.Text == "")
            {
                TextBox49.Text = "0";

            }
            if (TextBox50.Text == "")
            {
                TextBox50.Text = "0";

            }
            if (TextBox51.Text == "")
            {
                TextBox51.Text = "0";

            }
            if (TextBox52.Text == "")
            {
                TextBox52.Text = "0";

            }
            TextBox53.Text = (Convert.ToDouble(TextBox41.Text) + Convert.ToDouble(TextBox42.Text) + Convert.ToDouble(TextBox43.Text) + Convert.ToDouble(TextBox44.Text) + Convert.ToDouble(TextBox45.Text) + Convert.ToDouble(TextBox46.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox47.Text) + Convert.ToDouble(TextBox48.Text) + Convert.ToDouble(TextBox49.Text) + Convert.ToDouble(TextBox50.Text) + Convert.ToDouble(TextBox51.Text) + Convert.ToDouble(TextBox52.Text)).ToString();
            double totalinvest = Convert.ToDouble(TextBox53.Text);
            if (TextBox55.Text == "")
            {
                TextBox55.Text = "0";

            }
            TextBox56.Text = TextBox55.Text.ToString();
            double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

            if (asdf < 1)
            {

                TextBox57.Text = Convert.ToString(asdf);
                double A = Convert.ToDouble(TextBox12.Text);//Gross
                double AA = (A * 12);

                double yrlyprft = AA - 0;




                DataSet ds10 = new DataSet();

                ds10 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");
                for (int i = 0; i < ds10.Tables[0].Rows.Count; i++)
                {
                    double lbl3 = Convert.ToDouble(ds10.Tables[0].Rows[i]["FromRs"]);
                    double lbl4 = Convert.ToDouble(ds10.Tables[0].Rows[i]["ToRs"]);
                    if (yrlyprft > lbl3 && yrlyprft < lbl4)
                    {
                        double taxespinper = Convert.ToDouble(ds10.Tables[0].Rows[i]["Taxinper"]);
                        if (taxespinper == 0)
                        {
                            txtincometaxperyear.Text = "0";
                            txtincometaxpermonth.Text = "0";
                            return;
                        }
                        else
                        {
                            int taxesinperans = (Int32)(yrlyprft / taxespinper);
                            //   double taxesinperansfinal = taxesinperans / 12;
                            txtincometaxperyear.Text = "";
                            //            txtIncomeTax.Text = taxesinperansfinal.ToString();
                            txtincometaxperyear.Text = taxesinperans.ToString();
                            int monthincometax = (Int32)Convert.ToDouble(txtincometaxperyear.Text) / 12;
                            txtincometaxpermonth.Text = "";
                            txtincometaxpermonth.Text = monthincometax.ToString();
                            aobj.IncomeTax = txtincometaxpermonth.Text;
                            return;
                        }
                    }
                }

            }










 
    
    }
    catch (Exception)
    {
        System.Windows.Forms.MessageBox.Show("Enter Correct Year/ Incorrect Data");
    }
   
}
protected void BtnCancel_Click(object sender, EventArgs e)
{
    Response.Redirect("~/StaffPanel/IncomeTax.aspx");
}
protected void Btnupdate_Click(object sender, EventArgs e)
{
    try
    {
        string a = Session["new"].ToString();

        DataSet ds1 = new DataSet();
        ds1 = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where UserName='" + a + "'");
        int b = Convert.ToInt16(ds1.Tables[0].Rows[0]["Eid"]);

        DataSet ds2 = new DataSet();
        ds2 = aobj.sel("select Eid from tbl_TDS where Eid =" + b + "");

        aobj.ins("update tbl_TDS SET A1=" + TextBox1.Text + ",A2=" + TextBox2.Text + ",A3=" + TextBox3.Text + ",A4=" + TextBox4.Text + ",A41=" + TextBox5.Text + ",A5=" + TextBox6.Text + ",A51=" + TextBox7.Text + ",A6=" + TextBox8.Text + ",A7=" + TextBox9.Text + ",A8=" + TextBox10.Text + ",A9=" + TextBox11.Text + ",A10=" + TextBox12.Text + ",B11=" + TextBox13.Text + ",B111=" + TextBox14.Text + ",B112=" + TextBox15.Text + ",B12=" + TextBox16.Text + ",B13=" + TextBox17.Text + ",B14=" + TextBox18.Text + ",B2=" + TextBox19.Text + ",B3=" + TextBox20.Text + ",B4=" + TextBox21.Text + ",B5=" + TextBox22.Text + ",B6=" + TextBox23.Text + ",B7=" + TextBox24.Text + ",C=" + TextBox25.Text + ",D1=" + TextBox26.Text + ",D2=" + TextBox27.Text + ",D3=" + TextBox28.Text + ",D4=" + TextBox29.Text + ",D5=" + TextBox30.Text + ",D6=" + TextBox31.Text + ",D7=" + TextBox32.Text + ",D8=" + TextBox33.Text + ",E=" + TextBox34.Text + ",F11=" + TextBox35.Text + ",G11=" + TextBox36.Text + ",H=" + TextBox38.Text + ",I=" + TextBox68.Text + ",I1=" + TextBox39.Text + ",I2=" + TextBox40.Text + ",J=" + TextBox41.Text + ",K11=" + TextBox42.Text + ",K2=" + TextBox43.Text + ",K3=" + TextBox44.Text + ",K4=" + TextBox45.Text + ",K5=" + TextBox46.Text + ",K6=" + TextBox47.Text + ",K7=" + TextBox48.Text + ",K8=" + TextBox49.Text + ",K9=" + TextBox50.Text + ",K10=" + TextBox51.Text + ",K111=" + TextBox52.Text + ",K12=" + TextBox53.Text + ",L=" + TextBox54.Text + ",L1=" + TextBox55.Text + ",L2=" + TextBox56.Text + ",M=" + TextBox57.Text + ",N=" + TextBox58.Text + ",O1=" + TextBox60.Text + ",O11=" + TextBox61.Text + ",O2=" + TextBox62.Text + ",P=" + TextBox63.Text + ",Q=" + TextBox64.Text + ",R=" + TextBox65.Text + ",R1=" + TextBox66.Text + ",S=" + TextBox67.Text + ",ITPyear=" + txtincometaxperyear.Text + ",ITPmonth=" + txtincometaxpermonth.Text + ",FinancialYear=" + ddlyear2.SelectedItem.Value + " where Eid=" + b + " ");
        LblError.Text = "";
        System.Windows.Forms.MessageBox.Show("Record Updated of '" + a + "'");
        // Response.Redirect("~/StaffPanel/IncomeTax.aspx");
        ddlyear2.Enabled = true;



        //DataSet ds1 = new DataSet();
        //ds1 = aobj.sel("select Eid, DesignationId from tbl_EmpPrsnlDetail where Eid='" + a + "'");
        //int b = Convert.ToInt16(ds1.Tables[0].Rows[0]["Eid"]);






        DataSet john = new DataSet();

        john = aobj.sel("select * from tbl_TDS where Eid='" + b + "'");
        TextBox1.Text = "" + john.Tables[0].Rows[0]["A1"].ToString();
        TextBox2.Text = "" + john.Tables[0].Rows[0]["A2"].ToString();
        TextBox3.Text = "" + john.Tables[0].Rows[0]["A3"].ToString();
        TextBox4.Text = "" + john.Tables[0].Rows[0]["A4"].ToString();
        TextBox5.Text = "" + john.Tables[0].Rows[0]["A41"].ToString();
        TextBox6.Text = "" + john.Tables[0].Rows[0]["A5"].ToString();
        TextBox7.Text = "" + john.Tables[0].Rows[0]["A51"].ToString();
        TextBox8.Text = "" + john.Tables[0].Rows[0]["A6"].ToString();
        TextBox9.Text = "" + john.Tables[0].Rows[0]["A7"].ToString();
        TextBox10.Text = "" + john.Tables[0].Rows[0]["A8"].ToString();
        TextBox11.Text = "" + john.Tables[0].Rows[0]["A9"].ToString();
        TextBox12.Text = "" + john.Tables[0].Rows[0]["A10"].ToString();
        TextBox13.Text = "" + john.Tables[0].Rows[0]["B11"].ToString();
        TextBox14.Text = "" + john.Tables[0].Rows[0]["B111"].ToString();
        TextBox15.Text = "" + john.Tables[0].Rows[0]["B112"].ToString();
        TextBox16.Text = "" + john.Tables[0].Rows[0]["B12"].ToString();
        TextBox17.Text = "" + john.Tables[0].Rows[0]["B13"].ToString();
        TextBox18.Text = "" + john.Tables[0].Rows[0]["B14"].ToString();
        TextBox19.Text = "" + john.Tables[0].Rows[0]["B2"].ToString();
        TextBox20.Text = "" + john.Tables[0].Rows[0]["B3"].ToString();
        TextBox21.Text = "" + john.Tables[0].Rows[0]["B4"].ToString();
        TextBox22.Text = "" + john.Tables[0].Rows[0]["B5"].ToString();
        TextBox23.Text = "" + john.Tables[0].Rows[0]["B6"].ToString();
        TextBox24.Text = "" + john.Tables[0].Rows[0]["B7"].ToString();
        TextBox25.Text = "" + john.Tables[0].Rows[0]["C"].ToString();
        TextBox26.Text = "" + john.Tables[0].Rows[0]["D1"].ToString();
        TextBox27.Text = "" + john.Tables[0].Rows[0]["D2"].ToString();
        TextBox28.Text = "" + john.Tables[0].Rows[0]["D3"].ToString();
        TextBox29.Text = "" + john.Tables[0].Rows[0]["D4"].ToString();
        TextBox30.Text = "" + john.Tables[0].Rows[0]["D5"].ToString();
        TextBox31.Text = "" + john.Tables[0].Rows[0]["D6"].ToString();
        TextBox32.Text = "" + john.Tables[0].Rows[0]["D7"].ToString();
        TextBox33.Text = "" + john.Tables[0].Rows[0]["D8"].ToString();
        TextBox34.Text = "" + john.Tables[0].Rows[0]["E"].ToString();
        TextBox35.Text = "" + john.Tables[0].Rows[0]["F11"].ToString();
        TextBox36.Text = "" + john.Tables[0].Rows[0]["G11"].ToString();
        TextBox38.Text = "" + john.Tables[0].Rows[0]["H"].ToString();
        TextBox68.Text = "" + john.Tables[0].Rows[0]["I"].ToString();
        TextBox39.Text = "" + john.Tables[0].Rows[0]["I1"].ToString();
        TextBox40.Text = "" + john.Tables[0].Rows[0]["I2"].ToString();
        TextBox41.Text = "" + john.Tables[0].Rows[0]["J"].ToString();
        TextBox42.Text = "" + john.Tables[0].Rows[0]["K11"].ToString();
        TextBox43.Text = "" + john.Tables[0].Rows[0]["K2"].ToString();
        TextBox44.Text = "" + john.Tables[0].Rows[0]["K3"].ToString();
        TextBox45.Text = "" + john.Tables[0].Rows[0]["K4"].ToString();
        TextBox46.Text = "" + john.Tables[0].Rows[0]["K5"].ToString();
        TextBox47.Text = "" + john.Tables[0].Rows[0]["K6"].ToString();
        TextBox48.Text = "" + john.Tables[0].Rows[0]["K7"].ToString();
        TextBox49.Text = "" + john.Tables[0].Rows[0]["K8"].ToString();
        TextBox50.Text = "" + john.Tables[0].Rows[0]["K9"].ToString();
        TextBox51.Text = "" + john.Tables[0].Rows[0]["K10"].ToString();
        TextBox52.Text = "" + john.Tables[0].Rows[0]["K111"].ToString();
        TextBox53.Text = "" + john.Tables[0].Rows[0]["K12"].ToString();
        TextBox54.Text = "" + john.Tables[0].Rows[0]["L"].ToString();
        TextBox55.Text = "" + john.Tables[0].Rows[0]["L1"].ToString();
        TextBox56.Text = "" + john.Tables[0].Rows[0]["L2"].ToString();
        TextBox57.Text = "" + john.Tables[0].Rows[0]["M"].ToString();
        TextBox58.Text = "" + john.Tables[0].Rows[0]["N"].ToString();
        TextBox60.Text = "" + john.Tables[0].Rows[0]["O1"].ToString();
        TextBox61.Text = "" + john.Tables[0].Rows[0]["O11"].ToString();
        TextBox62.Text = "" + john.Tables[0].Rows[0]["O2"].ToString();
        TextBox63.Text = "" + john.Tables[0].Rows[0]["P"].ToString();
        TextBox64.Text = "" + john.Tables[0].Rows[0]["Q"].ToString();
        TextBox65.Text = "" + john.Tables[0].Rows[0]["R"].ToString();
        TextBox66.Text = "" + john.Tables[0].Rows[0]["R1"].ToString();
        TextBox67.Text = "" + john.Tables[0].Rows[0]["S"].ToString();
        txtincometaxperyear.Text = "" + john.Tables[0].Rows[0]["ITPyear"].ToString();
        txtincometaxpermonth.Text = "" + john.Tables[0].Rows[0]["ITPmonth"].ToString();
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Updated Successfully');", true);
        btnsubmit.Visible = true;
        Btnupdate.Visible = false;
        BtnCancel.Visible = false;
    }
    catch (Exception)
    {
        System.Windows.Forms.MessageBox.Show("There is a problem In database Please retry");
        //     Response.Redirect("~/StaffPanel/IncomeTax.aspx");

    }
    finally
    {
        Response.Redirect("~/StaffPanel/IncomeTax.aspx");

 
    }

}
protected void TextBox26_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text=="")
        {
            TextBox26.Text = "0";
        
        }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();
}
protected void TextBox27_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();

}
protected void TextBox28_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();

}
protected void TextBox29_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();
}
protected void TextBox30_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();

}
protected void TextBox31_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();
}
protected void TextBox32_TextChanged(object sender, EventArgs e)
{
    if (TextBox26.Text == "")
    {
        TextBox26.Text = "0";

    }
    if (TextBox27.Text == "")
    {
        TextBox27.Text = "0";

    }
    if (TextBox28.Text == "")
    {
        TextBox28.Text = "0";

    }
    if (TextBox29.Text == "")
    {
        TextBox29.Text = "0";

    }
    if (TextBox30.Text == "")
    {
        TextBox30.Text = "0";

    }
    if (TextBox31.Text == "")
    {
        TextBox31.Text = "0";

    }
    if (TextBox32.Text == "")
    {
        TextBox32.Text = "0";

    }
    double abc = Convert.ToDouble(TextBox26.Text.ToString()) + Convert.ToDouble(TextBox27.Text.ToString()) + Convert.ToDouble(TextBox28.Text.ToString()) + Convert.ToDouble(TextBox29.Text.ToString()) + Convert.ToDouble(TextBox30.Text.ToString()) + Convert.ToDouble(TextBox31.Text.ToString()) + Convert.ToDouble(TextBox32.Text.ToString());
    Int32 abcd = Convert.ToInt32(abc);
    TextBox33.Text = (Convert.ToDouble(abcd)).ToString();
    double asdf = Convert.ToDouble(TextBox25.Text) + Convert.ToDouble(TextBox33.Text);
    Int32 asd = Convert.ToInt32(asdf);
    TextBox34.Text = asd.ToString();
}
protected void TextBox55_TextChanged(object sender, EventArgs e)
{
    if (TextBox55.Text == "")
    {
        TextBox55.Text = "0";

    }
    TextBox56.Text = TextBox55.Text.ToString();
    double asdf = Convert.ToDouble(TextBox53.Text) + Convert.ToDouble(TextBox56.Text);

    TextBox57.Text = Convert.ToString(asdf);
   
}
protected void TextBox33_TextChanged(object sender, EventArgs e)
{
   
}
protected void TextBox25_TextChanged(object sender, EventArgs e)
{
   
}
}

