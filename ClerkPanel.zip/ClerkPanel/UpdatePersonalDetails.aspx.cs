﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class ClerkPanel_UpdatePersonalDetails : System.Web.UI.Page
{

    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["new"] == null)
        {
            Response.Redirect("login.aspx");
        }
        try
        {

            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
            cn.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from tbl_EmpPrsnlDetail where UserName='" + Session["new"].ToString() + "' ", cn);
            da.Fill(ds);



        }
        catch (Exception ex)
        {
            MessageBox.Show("Please check:" + ex.Message.ToString());
        }
        if (!IsPostBack)
        {
            Txtfirstname.Text = ds.Tables[0].Rows[0][1].ToString();
            Txtmiddlename.Text = ds.Tables[0].Rows[0][2].ToString();
            Txtsurname.Text = ds.Tables[0].Rows[0][3].ToString();
            //Ddlqualification.SelectedIndex= ds.Tables[0].Rows.[0][;
            Txtemail.Text = ds.Tables[0].Rows[0][8].ToString();
            Txtper.Text = ds.Tables[0].Rows[0][9].ToString();
            Txttemp.Text = ds.Tables[0].Rows[0][10].ToString();
            Txtpincode.Text = ds.Tables[0].Rows[0][11].ToString();
            Txtcontactmob.Text = ds.Tables[0].Rows[0][14].ToString();
            Txtphone.Text = ds.Tables[0].Rows[0][15].ToString();
        }
    }

    protected void Btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = "update tbl_EmpPrsnlDetail set FirstName='" + Txtfirstname.Text + "',MiddleName='" + Txtmiddlename.Text + "',Surname='" + Txtsurname.Text + "',Email='" + Txtemail.Text + "',PermAddress='" + Txtper.Text + "',TempAddress='" + Txttemp.Text + "',PinCode='" + Txtpincode.Text + "',ContactMob='" + Txtcontactmob.Text + "',Phone='" + Txtphone.Text + "',QualificationId='" + Ddlqualification.SelectedItem.Value + "' where UserName='" + Session["new"].ToString() + "'";
            cmd.Connection = cn;
            cmd.ExecuteNonQuery();



            Lbliferror.Text = Session["new"].ToString() + " Updated successfuly........";
            Lbliferror.Visible = true;
        }
        catch (Exception ex)
        {
            Lbliferror.Text = "Please Check " + ex.Message.ToString();
        }
    }
}