﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;

public partial class StaffPanel_ViewOwnsAttendance : System.Web.UI.Page
{
    ClsDB dbobj = new ClsDB();
    Attendance aObj = new Attendance();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["new"] != null)
        {

            dbobj.SQLStatement = " Select Eid from tbl_EmpPrsnlDetail where UserName= '" + Session["new"].ToString() + "'";

            DataTable dtCity = new DataTable();

            dtCity = dbobj.ResultSet();
            if (dtCity != null)
            {
                aObj._eid = Convert.ToInt32(dtCity.Rows[0].ItemArray[0]);

                GridView1.DataSource = aObj.GetAttById(aObj._eid);
                GridView1.DataBind();
            }
        }
    }
   
}