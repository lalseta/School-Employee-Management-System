﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AdminPrincipalPanel_Test : System.Web.UI.Page
{
    StateCls coObj=new StateCls();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillCountry();


            if (Request.QueryString["Id"] != null)
            {
                ViewState["Id"] = Request.QueryString["Id"];
                FillData();
                btncosave.Text = "Update";
            }
            else
            {
                btncosave.Text = "Save";

            }

        }
    }

      void FillCountry()
    {
        gv_country.DataSource = coObj.GetCountryList();
        gv_country.DataBind();
    }
    
      protected void FillData()
    {

        coObj.GetCountrybyPK(Convert.ToInt32(ViewState["Id"]));
        txt_m_country.Text = coObj._State_Name.ToString();
        // DropDownList1.SelectedItem.Text = userObj._City.ToString();

    }
    protected void  Button1_Click(object sender, EventArgs e)
{

}
protected void  btncosave_Click(object sender, EventArgs e)
{
    Boolean err = false;
    if (txt_m_country.Text.Trim().Length == 0)
    {
        Label_Co.Visible = true;
        err = true;
    }
    else
    {
        Label_Co.Visible = false;
    }

    if (err != true)
    {

        if (ViewState["Id"] != null)
        {
            UpdateCountry();
            FillCountry();
            //Response.Write("<script>alert('Update Successfully')</script>");
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Updated Successfully');", true); 
            txt_m_country.Text = "";
            btncosave.Text = "Save";
        }
        else
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from tbl_State where StateName = '"+ txt_m_country.Text +"'",cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('State '"+txt_m_country.Text+"' Inserted Successfully');", true);
            if (ds.Tables[0].Rows.Count == 0)
            {
                insertCountry();
                FillCountry();
            }
            
        }
    }
}

public void UpdateCountry()
{
    SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    cn.Open();

    SqlDataAdapter da = new SqlDataAdapter("select * from tbl_State where StateName = '" + txt_m_country.Text + "'", cn);
    DataSet ds = new DataSet();
    da.Fill(ds);

    if (ds.Tables[0].Rows.Count == 0)
    {
        //insertCountry();
        //FillCountry();
        coObj._State_Name = txt_m_country.Text;

        coObj._SID = Convert.ToInt32(ViewState["Id"]);

        ViewState["Id"] = coObj.UpdateCountryList();
  
    }
}
   
      void insertCountry()
    {

        coObj._State_Name = Convert.ToString(txt_m_country.Text);

        int r = 0;
        
        r=coObj.insertCountry();

       // Response.Write("<script>alert('Inserted successfully');</script>");
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);

        txt_m_country.Text = "";

 
    }

   
protected void  gv_country_row_cmd(object sender, GridViewCommandEventArgs e)
{
    if (e.CommandName == "cmdEdit")
    {
        Response.Redirect("Test.aspx?id=" + e.CommandArgument);
    }
    if (e.CommandName == "cmdDelete")
    {
        coObj._SID = Convert.ToInt32(e.CommandArgument);
        DeleteCountry();

    }
}
public void DeleteCountry()
{

    ViewState["Id"] = coObj.DeleteCountryList();
    FillCountry();
    //Response.Write("<script>alert('Deleted successfully');</script>");
    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Deleted Successfully');", true);

}


protected void gv_country_PageIndexChanging(object sender, GridViewPageEventArgs e)
{
    gv_country.PageIndex = e.NewPageIndex;

    FillCountry();
}
}
