﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class AdminPrincipalPanel_ActiveDeactive : System.Web.UI.Page
{
     SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ConnectionString);
     IUDS john = new IUDS();
    public DataTable table = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        conn.Open();
        if (!IsPostBack)
        {
            LoadData();
        }
    }
    private void LoadData()
    {
        string asdf=Session["new"].ToString();

        string query = "SELECT e.[Eid], e.[FirstName], e.[MiddleName], e.[Surname], e.[UserName],e.[DesignationId], d.[DesignationName],e.[Activate_Deactivate] FROM [tbl_EmpPrsnlDetail] e INNER JOIN [tbl_Designation] d ON e.[DesignationId]=d.[DesignationId] WHERE e.[UserName]!='"+asdf+"' ORDER BY e.[Eid]";

        SqlDataAdapter da = new SqlDataAdapter(query, conn);
        
        da.Fill(table);

        GridView1.DataSource = table;
        GridView1.DataBind();
    }


    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ConnectionString);
        //conn.Open();


        //SqlDataAdapter da = new SqlDataAdapter("SELECT e.[Eid], e.[FirstName], e.[MiddleName], e.[Surname], e.[UserName],e.[DesignationId], d.[DesignationName],e.[Activate_Deactivate] FROM [tbl_EmpPrsnlDetail] e INNER JOIN [tbl_Designation] d ON e.[DesignationId]=d.[DesignationId] WHERE ((e.[DesignationId] &lt;&gt; @DesignationId) AND (e.[DesignationId] &lt;&gt; @DesignationId2)) ORDER BY e.[Eid]", conn);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //    foreach (GridViewRow row in GridView1.Rows)
        //{
            //RadioButtonList rbl = (RadioButtonList)row.FindControl("rbtnactdeact");
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            RadioButtonList rbl = (RadioButtonList)e.Row.FindControl("rbtnactdeact");
            int str = Convert.ToInt16(e.Row.Cells[6].Text);
            //for (int i = 0; i < table.Rows.Count; i++)
            //{
            if (str == 1)
            {
                rbl.Items[0].Selected = true;
            }
            else
            {
                //                    int eid = Convert.ToInt16(row.Cells[0].Text);
                rbl.Items[1].Selected = true;
                //                  string query=  "update tbl_EmpPrsnlDetail set Activate_Deactivate=0 where Eid="+ eid +"";
                //                john.ins(query);
            }
        }
          //  }
        //}
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rbtnactdeact_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList chkStatus = (RadioButtonList)sender;
        GridViewRow row = (GridViewRow)chkStatus.NamingContainer;

        RadioButtonList rbl = (RadioButtonList)row.FindControl("rbtnactdeact");
        int str = Convert.ToInt16(row.Cells[6].Text);
        //for (int i = 0; i < table.Rows.Count; i++)
        //{
        int eid = Convert.ToInt16(row.Cells[0].Text);
        if (rbl.Items[0].Selected == true)
        {
            string query=  "update tbl_EmpPrsnlDetail set Activate_Deactivate=1 where Eid="+ eid +"";
            john.ins(query);
        }
        else
        {
            string query = "update tbl_EmpPrsnlDetail set Activate_Deactivate=0 where Eid=" + eid + "";
            john.ins(query);
        }

        LoadData();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        LoadData();
    }
}