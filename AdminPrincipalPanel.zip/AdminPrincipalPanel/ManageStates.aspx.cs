﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AdminPrincipalPanel_ManageStates : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
        if (!IsPostBack)
        {
            grid();
        }
    }
    public void grid()
    {
        SqlDataAdapter da = new SqlDataAdapter("select * from tbl_State", cn);
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int StateId = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);
        //cn.Open();
        cmd.CommandText = "delete from tbl_State where StateId='"+StateId+"'";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        //cn.Close();
        grid();

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        int index = GridView1.EditIndex;
        GridViewRow row = GridView1.Rows[index];
        int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
        grid();   
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int index = GridView1.EditIndex;

        GridViewRow row = GridView1.Rows[index];
        int StateId = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
        TextBox statename = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];
        
        cmd = new SqlCommand();
        cmd.CommandText = "update tbl_State set StateName='" + statename.Text + "' where StateId='" + StateId + "'";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        grid();
        cn.Close();

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}