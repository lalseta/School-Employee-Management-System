﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;


public partial class AdminPrincipalPanel_Registration : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    AttendancePayrollStateCity obj = new AttendancePayrollStateCity();
    IUDS obj1 = new IUDS();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        Txtjoindate_CalendarExtender.EndDate = DateTime.Now;
        CalendarExtenderfromdate.EndDate = DateTime.Now;
        CalendarExtendertodate.EndDate = DateTime.Now;
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        if (!IsPostBack)
        {
            //dropdownlist();
            obj.dropdown("select * from tbl_State", Ddlstate);






        }
    }


    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked)
        {
            Txttempadd.Text = Txtpermadd.Text;
        }
        else
        {
            Txttempadd.Text = "";
        }

    }

    protected void Ddlstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        obj.dropdown("select * from tbl_City where StateId='" + Ddlstate.SelectedValue + "'", Ddlcity);

    }
    protected void Btnchkavail_Click(object sender, EventArgs e)
    {
        checkUserName();
    }

    protected void btnfn_click(object sender, EventArgs e)
    {
        checkUserName();
    }

    public int checkUserName()
    {
        try
        {
            ds = obj1.sel("select UserName from tbl_EmpPrsnlDetail where UserName='" + Txtusername.Text + "'");
            if (ds.Tables[0].Rows.Count > 0)
            {
                Txtusername.Text = "";

                Lblusername.Text = "Username Already Exist..";
                Lblusername.Visible = true;

                return 1;

            }
            else
            {
                Lblusername.Text = "You can use this username";
                Lblusername.Visible = true;
                return 0;
            }


        }
        catch (Exception)
        {
            LblError.Text = " Sorry an error occured. Please Re-enter the registration form.";
            Response.Redirect("StaffRegistration.aspx");
            return 1;
        }
    }
    protected void txtfromdate_textchanged(object sender, EventArgs e)
    {

        try
        {
            CalendarExtendertodate.StartDate = CalendarExtenderfromdate.SelectedDate;
            DateTime dob = Convert.ToDateTime(Txtdob.Text);
            int age = (int)Math.Floor((DateTime.Now - dob).TotalDays / 365.25D);

            //string
            //    Txtfromdate.Text
            if (age > 18)
            {
                lblfrmdate.Text = "Invalid Date";
            }
        }
        catch (Exception)
        {
            Txtfromdate.Text = "";
            lblfrmdate.Text = "Re-Enter Date in Format DD/MM/YYYY";
        }
    }








    protected void Btnsignup_Click(object sender, EventArgs e)
    {
        if (checkUserName() == 0)
        {
            try
            {
                cn.Open();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "spregistration";
                cmd.Parameters.AddWithValue("@FirstName", Txtfirstname.Text.ToString());
                cmd.Parameters.AddWithValue("@MiddleName", Txtmiddlename.Text.ToString());
                cmd.Parameters.AddWithValue("@Surname", Txtsurname.Text.ToString());
                cmd.Parameters.AddWithValue("@PermAddress", Txtpermadd.Text.ToString());
                cmd.Parameters.AddWithValue("@TempAddress", Txttempadd.Text.ToString());
                cmd.Parameters.AddWithValue("@StateId", Ddlstate.SelectedValue);
                cmd.Parameters.AddWithValue("@CityId", Ddlcity.SelectedValue);
                cmd.Parameters.AddWithValue("@DateOfBirth", Convert.ToDateTime(Txtdob.Text));
                cmd.Parameters.AddWithValue("@Email", Txtemail.Text.ToString());
                cmd.Parameters.AddWithValue("@Gender", Rblmf.SelectedValue);
                cmd.Parameters.AddWithValue("@PinCode", Txtpincode.Text);
                cmd.Parameters.AddWithValue("@ContactMob", Txtmob.Text);
                cmd.Parameters.AddWithValue("@Phone", Txtphone.Text);
                cmd.Parameters.AddWithValue("@BloodGroup", Ddlbloodgroup.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@Religion", Ddlreligion.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Caste", Txtcaste.Text.ToString());
                cmd.Parameters.AddWithValue("@Category", Ddlcategory.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@QualificationId", Ddlqualification.SelectedValue);
                cmd.Parameters.AddWithValue("@MainSubject", Txtmainsub.Text.ToString());
                cmd.Parameters.AddWithValue("@Experience", TxtExperience.Text);
                cmd.Parameters.AddWithValue("@PassingYear", Ddlpassyear.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@Result", Txtresult.Text);
                cmd.Parameters.AddWithValue("@University", Txtuniversity.Text.ToString());
                cmd.Parameters.AddWithValue("@IntrestedSubjects", Txtinterestsub.Text.ToString());
                cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(Txtfromdate.Text));
                cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(Txttodate.Text));
                cmd.Parameters.AddWithValue("@DesignationId", Ddldesignation.SelectedValue);
                cmd.Parameters.AddWithValue("@Institute", TxtInstitute.Text.ToString());
                cmd.Parameters.AddWithValue("@JoiningDate", Convert.ToDateTime(Txtjoindate.Text));
                cmd.Parameters.AddWithValue("@EmployeeType", Ddlemployeetype.SelectedValue);
                cmd.Parameters.AddWithValue("@PostId", DdlPost.SelectedValue);
                cmd.Parameters.AddWithValue("@PANNumber", Txtpannumber.Text.ToString());
                cmd.Parameters.AddWithValue("@AccountNumber", txtaccnumbr.Text);
                cmd.Parameters.AddWithValue("@MarkOfIdentification", Txtidentmark.Text.ToString());
                cmd.Parameters.AddWithValue("@Remark", Txtremark.Text.ToString());
                cmd.Parameters.AddWithValue("@UserName", Txtusername.Text.ToString());
                cmd.Parameters.AddWithValue("@Password", Txtpassword.Text.ToString());
                cmd.ExecuteNonQuery();

                LblError.Text = "Staff Registered Successfully";
                LblError.Visible = true;
                cleardata();

            }

            catch (Exception)
            {
                LblError.Visible = true;
                LblError.Text = "Please Enter correct Data or connection Lost";

            }
            finally
            {
                cn.Close();
            }

            //char a = '0';
            //string sql1 = "update tbl_EmpPrsnlDetail set Active_Deactivate='" + a + "'where UserName='" + Txtusername.Text + "'";

            //SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ConnectionString);

            //SqlCommand cmd1 = new SqlCommand(sql1, conn1);


            //try
            //{
            //    cn.Open();
            //    cmd1.ExecuteNonQuery();
            //    LblError.Text = "Staff Registered successfully";
            //    cleardata();
            //    Response.Redirect("HomePage.aspx");
            //    MessageBox.Show(" Registration of Staff has been Saved Successfully...");
            //}
            //catch (Exception)
            //{
            //    LblError.Text = "  Not Saved.. Try Again...";
            //}
            //finally
            //{
            //    cn.Close();
            //}
        }
    }
    private void cleardata()
    {
        Txtusername.Text = "";
        Txtuniversity.Text = "";
        Txttempadd.Text = "";
        Txtsurname.Text = "";
        Txtresult.Text = "";
        Txtremark.Text = "";
        Txtpincode.Text = "";
        Txtphone.Text = "";
        Txtpermadd.Text = "";
        Txtidentmark.Text = "";
        Txtpassword.Text = "";
        Txtcaste.Text = "";
        Txtdob.Text = "";
        Txtemail.Text = "";
        Txtconfirmpassword.Text = "";
        Txtmainsub.Text = "";
        Txtmiddlename.Text = "";
        Txtmob.Text = "";
        Txtpannumber.Text = "";
        Txtinterestsub.Text = "";
        TxtExperience.Text = "";
        Txtremark.Text = "";
        Txtfromdate.Text = "";
        Txttodate.Text = "";
        TxtInstitute.Text = "";
        txtaccnumbr.Text = "";
    }
    protected void Txtjoindate_TextChanged(object sender, EventArgs e)
    {
        //try
        //{
        //    DateTime d = Convert.ToDateTime(Txtjoindate.Text);

        //    if (d > System.DateTime.Now)
        //    {
        //        Label1.Visible = true;
        //    }
        //    else
        //    {
        //        Label1.Visible = false;
        //    }
        //}
        //catch (Exception)
        //{
        //    Label1.Visible = true;

        //}
    }
    //protected void Txtfromdate_TextChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        DateTime d = Convert.ToDateTime(Txtfromdate.Text);

    //        if (d > System.DateTime.Now)
    //        {
    //            lblfrmdate.Visible = true;
    //        }
    //        else
    //        {
    //            lblfrmdate.Visible = false;
    //        }
    //    }
    //    catch (Exception)
    //    {
    //        lblfrmdate.Visible = true;

    //    }

    //}
    //protected void Txttodate_TextChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        DateTime d = Convert.ToDateTime(Txttodate.Text);

    //        if (d > System.DateTime.Now)
    //        {
    //            lbltodate.Visible = true;
    //        }
    //        else
    //        {
    //            lbltodate.Visible = false;
    //        }
    //    }
    //    catch (Exception)
    //    {
    //        lbltodate.Visible = true;
    //    }

    //}

    //protected void Txtfromdate_TextChanged(object sender, EventArgs e)
    //{
    //    
    //}
}
