﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.IO;
using System.Text;
using RKLib.ExportData;

public partial class AdminPrincipalPanel_ReportsforPayslip : System.Web.UI.Page
{
    IUDS aobj = new IUDS();

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
        cn.Open();
        if (!IsPostBack)
        {

            SqlDataAdapter da = new SqlDataAdapter("SELECT [Eid], [UserName] FROM [tbl_EmpPrsnlDetail] WHERE (([DesignationId] <> 1) AND ([DesignationId] <> 6)) ORDER BY [Eid]", cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlEmpID.DataSource = ds;
            ddlEmpID.DataTextField = "UserName";
            ddlEmpID.DataValueField = "Eid";
            ddlEmpID.DataBind();
            ddlEmpID.Items.Insert(0, "-----Select-----");

        }
    }
    protected void Rbtnlist_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Rbtnlist.SelectedIndex == 0)
        {
            PnlSpecific.Visible = true;
            PnlAll.Visible = false;
        
        }
       if(Rbtnlist.SelectedIndex==1)
       {
           PnlSpecific.Visible = false;
           PnlAll.Visible = true;
       }

    }
    protected void BtnPrint_Click(object sender, EventArgs e)
    {
        aobj.FillGrid("Select tbl_EmpMonthlySal.Id,tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.GradePay, tbl_EmpMonthlySal.Conveyance,tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.Username, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NetSalary, tbl_EmpPrsnlDetail.Eid from tbl_EmpMonthlySal INNER JOIN  tbl_EmpPrsnlDetail ON  tbl_EmpMonthlySal.Username = tbl_EmpPrsnlDetail.UserName where tbl_EmpMonthlySal.Username = '" + ddlEmpID.SelectedItem.Text + "' AND tbl_EmpMonthlySal.FinancialYear = '" + ddlyear2.SelectedItem.Text + "'", GridView1);
    //    aobj.FillGrid("SELECT tbl_EmpMonthlySal.Username, tbl_EmpPrsnlDetail.Eid, tbl_EmpPrsnlDetail.UserName AS Expr1, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NETSALARY, tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.FinancialYear, tbl_EmpMonthlySal.Conveyance, tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.GradePay FROM tbl_EmpMonthlySal CROSS JOIN tbl_EmpPrsnlDetail", GridView1);







        Response.ClearContent();
        Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "SpecificEmployee.xls"));
        Response.ContentType = "application/text";
        GridView1.AllowPaging = false;
        GridView1.DataSource = Session["GridData"];
        GridView1.DataBind();
        StringBuilder strbldr = new StringBuilder();
        for (int i = 0; i < GridView1.Columns.Count; i++)
        {
            //separting header columns text with comma operator
            strbldr.Append(GridView1.Columns[i].HeaderText + '\t');
        }
        //appending new line for gridview header row
        strbldr.Append("\r\n");

        DataSet ds = new DataSet();



        ds = aobj.sel("Select tbl_EmpMonthlySal.Id,tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.GradePay, tbl_EmpMonthlySal.Conveyance,tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.Username, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NetSalary, tbl_EmpPrsnlDetail.Eid from tbl_EmpMonthlySal INNER JOIN  tbl_EmpPrsnlDetail ON  tbl_EmpMonthlySal.Username = tbl_EmpPrsnlDetail.UserName where tbl_EmpMonthlySal.Username = '" + ddlEmpID.SelectedItem.Text + "' AND tbl_EmpMonthlySal.FinancialYear = '" + ddlyear2.SelectedItem.Text + "'");

        int cnt = ds.Tables[0].Rows.Count;

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

        for (int j = 0; j < cnt; j++)
        {
            for (int k = 0; k < GridView1.Columns.Count; k++)
            {
                //separating gridview columns with comma
                strbldr.Append(GridView1.Rows[j].Cells[k].Text + '\t');
            }
            //appending new line for gridview rows
            strbldr.Append("\r\n");
        }
        Response.Write(strbldr.ToString());
        Response.End();





    }
    protected void ddlEmpID_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BtnPrints_Click(object sender, EventArgs e)
    {
        aobj.FillGrid("Select tbl_EmpMonthlySal.Id,tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.GradePay, tbl_EmpMonthlySal.Conveyance,tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.Username, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NetSalary, tbl_EmpPrsnlDetail.Eid from tbl_EmpMonthlySal INNER JOIN  tbl_EmpPrsnlDetail ON  tbl_EmpMonthlySal.Username = tbl_EmpPrsnlDetail.UserName where tbl_EmpMonthlySal.FinancialYear = '" + DropDownList1.SelectedItem.Text + "'", GridView2);
        //    aobj.FillGrid("SELECT tbl_EmpMonthlySal.Username, tbl_EmpPrsnlDetail.Eid, tbl_EmpPrsnlDetail.UserName AS Expr1, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NETSALARY, tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.FinancialYear, tbl_EmpMonthlySal.Conveyance, tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.GradePay FROM tbl_EmpMonthlySal CROSS JOIN tbl_EmpPrsnlDetail", GridView1);







        Response.ClearContent();
        Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "AllEmployeeDetails.xls"));
        Response.ContentType = "application/text";
        GridView2.AllowPaging = false;
        GridView2.DataSource = Session["GridData"];
        GridView2.DataBind();
        StringBuilder strbldr = new StringBuilder();
        for (int i = 0; i < GridView2.Columns.Count; i++)
        {
            //separting header columns text with comma operator
            strbldr.Append(GridView2.Columns[i].HeaderText + '\t');
        }
        //appending new line for gridview header row
        strbldr.Append("\r\n");

        DataSet ds = new DataSet();



        ds = aobj.sel("Select tbl_EmpMonthlySal.Id,tbl_EmpMonthlySal.Name, tbl_EmpMonthlySal.GradePay, tbl_EmpMonthlySal.Conveyance,tbl_EmpMonthlySal.SpecialAllowance, tbl_EmpMonthlySal.Username, tbl_EmpMonthlySal.Post, tbl_EmpMonthlySal.BasicSalary, tbl_EmpMonthlySal.HRA, tbl_EmpMonthlySal.DA, tbl_EmpMonthlySal.MedicalAllowance, tbl_EmpMonthlySal.TravelingAllowance, tbl_EmpMonthlySal.Other, tbl_EmpMonthlySal.EmployeeProvidentFund, tbl_EmpMonthlySal.ProfessionalTax, tbl_EmpMonthlySal.IncomeTax, tbl_EmpMonthlySal.NetSalary, tbl_EmpPrsnlDetail.Eid from tbl_EmpMonthlySal INNER JOIN  tbl_EmpPrsnlDetail ON  tbl_EmpMonthlySal.Username = tbl_EmpPrsnlDetail.UserName where tbl_EmpMonthlySal.FinancialYear = '" + DropDownList1.SelectedItem.Text + "'");

        int cnt = ds.Tables[0].Rows.Count;

        GridView2.DataSource = ds.Tables[0];
        GridView2.DataBind();

        for (int j = 0; j < cnt; j++)
        {
            for (int k = 0; k < GridView2.Columns.Count; k++)
            {
                //separating gridview columns with comma
                strbldr.Append(GridView2.Rows[j].Cells[k].Text + '\t');
            }
            //appending new line for gridview rows
            strbldr.Append("\r\n");
        }
        Response.Write(strbldr.ToString());
        Response.End();





    }
}