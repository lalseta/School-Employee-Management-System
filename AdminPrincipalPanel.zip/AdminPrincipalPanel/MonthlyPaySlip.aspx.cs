﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.IO;
using System.Windows.Forms;
using System.Configuration;
using ASPSnippets.SmsAPI;

public partial class AdminPrincipalPanel_MonthlyPaySlip : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();

    public DataSet ds1 = new DataSet();

    public DataSet ds3 = new DataSet();
    public DataSet ds4 = new DataSet();
    public DataSet ds5 = new DataSet();
    public DataSet ds6 = new DataSet();
    public DataSet ds7 = new DataSet();
    public DataSet ds8 = new DataSet();
    public DataSet ds9 = new DataSet();
    public DataSet ds10 = new DataSet();
    public DataSet mobile = new DataSet();
    public DataSet msggg = new DataSet();
    public IUDS aobj = new IUDS();

    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {

            SqlDataAdapter da = new SqlDataAdapter("SELECT [Eid], [UserName] FROM [tbl_EmpPrsnlDetail] WHERE (([DesignationId] <> 1) AND ([DesignationId] <> 6)) ORDER BY [Eid]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlEmpID.DataSource = ds;
            ddlEmpID.DataTextField = "UserName";
            ddlEmpID.DataValueField = "Eid";
            ddlEmpID.DataBind();
            ddlEmpID.Items.Insert(0, "-----Select-----");

        }

    }


    protected void ddlEmpID_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ds1 = aobj.sel("select DISTINCT a.Eid, a.FirstName, a.MiddleName, a.Surname, a.JoiningDate,a.Email,a.Gender, a.DesignationId,a.ContactMob, b.DesignationName from tbl_EmpPrsnlDetail a join tbl_Designation b on a.DesignationId=b.DesignationId where Eid ='" + ddlEmpID.SelectedValue + "'");



            txtEmployeeName.Text = " " + ds1.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1.Tables[0].Rows[0]["Surname"].ToString();

            txtJoiningDate.Text = "" + Convert.ToDateTime(ds1.Tables[0].Rows[0]["JoiningDate"]).ToShortDateString();
            txtEmail.Text = "" + ds1.Tables[0].Rows[0]["Email"];
            txtGender.Text = "" + ds1.Tables[0].Rows[0]["Gender"].ToString();
            gendercalc();
            txtmobile.Text = "" + ds1.Tables[0].Rows[0]["ContactMob"].ToString();
            string designate = (string)ds1.Tables[0].Rows[0]["DesignationName"];
            txtPost.Text = designate;
            txtPost.Visible = true;
            //ds1.Clear();
            // DataSet ds2 = new DataSet();
            DataSet ds2 = new DataSet();
            ds2 = aobj.sel("select DISTINCT BasicSalary from tbl_BasicSalary where Eid ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "' ");
            txtBasicSal.Text = " " + ds2.Tables[0].Rows[0]["BasicSalary"].ToString();
            //// txtBasicSal.Text = "" + ds1.Tables[0].Rows[0]["BasicSalary"].ToString();

            ds2.Clear();
            ds2 = aobj.sel("select DISTINCT GradePay from tbl_BasicSalary where Eid ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "' ");
            txtGradePay.Text = " " + ds2.Tables[0].Rows[0]["GradePay"].ToString();




            ds3 = aobj.sel("select DISTINCT HRA from tbl_HRA where  AcademicYear='" + ddlyear2.SelectedValue + "' AND DesignationId='" + ds1.Tables[0].Rows[0]["DesignationId"] + "'");
            txtHRA.Text = "" + ds3.Tables[0].Rows[0]["HRA"].ToString();

            ds4 = aobj.sel("select DISTINCT DA from tbl_DA where AcademicYear='" + ddlyear2.SelectedValue + "'");
            txtDA.Text = "" + ds4.Tables[0].Rows[0]["DA"].ToString();
            // ds1.Clear();
            ds5 = aobj.sel("select DISTINCT MedicalAllowance from tbl_MedicalAllow where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            txtMedicalAllow.Text = "" + ds5.Tables[0].Rows[0]["MedicalAllowance"].ToString();
            //ds1.Clear();
            ds6 = aobj.sel("select DISTINCT TravellingAllowance from tbl_TA where DesignationId ='" + ds1.Tables[0].Rows[0]["DesignationId"] + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            txtTravellAllow.Text = "" + ds6.Tables[0].Rows[0]["TravellingAllowance"].ToString();

            // ds7 = aobj.sel("select select DISTINCT TravellingAllowance from tbl_TA where DesignationId");
            //totalearning();
            // ds1.Clear();

            // ds1 = aobj.sel("select DISTINCT DA from tbl_DA where AcademicYear='" + ddlyear2.SelectedValue + "'");
            // txtProfessionFund.Text = "" + ds1.Tables[0].Rows[0]["DA"].ToString();
            // ds1.Clear();
            // ds1 = aobj.sel("select DISTINCT MedicalAllowance from tbl_MedicalAllow where DesignationId ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            // txtProvidentFund.Text = "" + ds1.Tables[0].Rows[0]["MedicalAllowance"].ToString();
            // ds1.Clear();
            // ds1 = aobj.sel("select DISTINCT TravellingAllowance from tbl_TA where DesignationId ='" + ddlEmpID.SelectedValue + "' AND AcademicYear='" + ddlyear2.SelectedValue + "'");
            // txtIncomeTax.Text = "" + ds1.Tables[0].Rows[0]["TravellingAllowance"].ToString();
            // ds1.Clear();

            // totalearning();
            // totaldeducting();

            // netsal();

            //  ds1 = aobj.sel("select DISTINCT DA from tbl_DA where Eid='"+ddlEmpID.SelectedValue+"'");
        }
        catch (Exception)
        {
        
        System.Windows.Forms.MessageBox.Show("Please Enter Correct Year/ InValid Data");
        Response.Redirect("MonthlyPaySlip.aspx");
        }
    }




    protected void gendercalc()
    {
        string jenith = txtGender.Text.ToString();
        if (jenith == "m")
        {
            txtGender.Text = "Male";

        }
        else
        {
            txtGender.Text = "Female";
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            aobj.ins("insert into tbl_EmpMonthlySal(Username,Gender,Mobile,Post,BasicSalary,HRA,DA,MedicalAllowance,TravelingAllowance,TotalEarning,Other,EmployeeProvidentFund,ProfessionalTax,IncomeTax,TotalDeduction,NETSALARY,Name,Month,JoiningDate,FinancialYear,Conveyance) values('" + ddlEmpID.SelectedItem.ToString() + "','" + txtGender.Text.ToString() + "'," + txtmobile.Text + ",'" + txtPost.Text + "'," + txtBasicSal.Text + "," + txtHRA.Text + "," + txtDA.Text + "," + txtMedicalAllow.Text + "," + txtTravellAllow.Text + "," + txtTotalEarning.Text + "," + txtOther.Text + "," + txtProvidentFund.Text + "," + txtProfessionFund.Text + "," + txtIncomeTax.Text + "," + txtTotalDeduction.Text + "," + txtNetSalary.Text + ",'" + txtEmployeeName.Text.ToString() + "','" + DDlMonth.SelectedItem.Text + "','" + txtJoiningDate.Text + "','" + ddlyear2.SelectedItem.Text + "'," + txtConveyancy.Text + ")");
        }
        catch (Exception)
        {
            lblError.Text = " There is problem in connection and/or in correct data has been entered ";
        }

    }

  
    protected void btnreset_Click(object sender, EventArgs e)
    {
        ddlyear2.SelectedIndex = 0;
        DDlMonth.SelectedIndex = 0;
        ddlEmpID.SelectedIndex = 0;
        txtGradePay.Text = "";
        txtEmployeeName.Text = "";
        txtJoiningDate.Text = "";
        txtEmail.Text = "";
        txtGender.Text = "";
        txtmobile.Text = "";
        txtPost.Text = "";
        txtBasicSal.Text = "";
        txtHRA.Text = "";
        txtDA.Text = "";
        txtMedicalAllow.Text = "";
        txtTravellAllow.Text = "";
        txtConveyancy.Text = "0";
        txtSpecialAllow.Text = "0";
        txtOther.Text = "0";
        txteffectivedays.Text = "0";
        txtTotalIncrement.Text = "";
        txtProvidentFund.Text = "";
        txtProfessionFund.Text = "";
        txtIncomeTax.Text = "";
        txtTotalDeduction.Text = "";
        txtNetSalary.Text = "";
    }


    //public void totalearning()
    //{
    //    double a = Convert.ToDouble(txtBasicSal.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text);
    //    txtTotalEarning.Text = a.ToString();
    //}
    //protected void totaldeducting()
    //{
    //    double a = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
    //    txtTotalDeduction.Text = a.ToString();
    //}
    //protected void netsal()
    //{
    //    double a = Convert.ToDouble(txtTotalEarning.Text) + Convert.ToDouble(txtTotalDeduction.Text);
    //    txtNetSalary.Text = a.ToString();
    //}

    ////protected void btnreset_Click(object sender, EventArgs e)
    ////{
    ////    ddlEmpID.SelectedIndex = 0;
    ////}
    //protected void btnreset_Click(object sender, EventArgs e)
    //{






    void professiontaxes()
    {
        double prft = Convert.ToDouble(txtBasicSal.Text);
        ds8 = aobj.sel("select * from tbl_ProfessionalTax where AcademicYear='" + ddlyear2.SelectedValue + "'");

        for (int i = 0; i < ds8.Tables[0].Rows.Count; i++)
        {
            double lbl1 = Convert.ToDouble(ds8.Tables[0].Rows[i]["FromRs"]);
            double lbl2 = Convert.ToDouble(ds8.Tables[0].Rows[i]["ToRs"]);
            if (prft > lbl1 && prft < lbl2)
            {
                txtProfessionFund.Text = ds8.Tables[0].Rows[i]["TaxRs"].ToString();
                return;
            }
        }

    }
    //void incometaxes()
    //{
    //    double prft1 = Convert.ToDouble(txtTotalEarning.Text);
    //    double yrlyprft = prft1 * 12;
    //    ds9 = aobj.sel("select * from tbl_IncomeTax where AcademicYear='" + ddlyear2.SelectedValue + "'");

    //    for (int i = 0; i < ds9.Tables[0].Rows.Count; i++)
    //    {
    //        double lbl3 = Convert.ToDouble(ds9.Tables[0].Rows[i]["FromRs"]);
    //        double lbl4 = Convert.ToDouble(ds9.Tables[0].Rows[i]["ToRs"]);
    //        if (yrlyprft > lbl3 && yrlyprft < lbl4)
    //        {
    //            double taxespinper = Convert.ToDouble(ds9.Tables[0].Rows[i]["Taxinper"]);
    //            if (taxespinper == 0)
    //            {
    //                txtIncomeTax.Text = "0";
    //                return;
    //            }
    //            else
    //            {
    //                double taxesinperans = (yrlyprft / taxespinper);
    //                double taxesinperansfinal = taxesinperans / 12;

    //                txtIncomeTax.Text = taxesinperansfinal.ToString();
    //                return;
    //            }
    //        }
    //    }
    //}
    protected void txteffectivedays_TextChanged(object sender, EventArgs e)
    {
        try{
        if (txtConveyancy.Text == "")
        {
            txtConveyancy.Text = "0";
        }
        if (txtSpecialAllow.Text == "")
        {
            txtSpecialAllow.Text = "0";
        }
        if (txtOther.Text == "")
        {
            txtOther.Text = "0";
        }
        double asdfg = Convert.ToDouble(txteffectivedays.Text);

        if (asdfg > 30)
        {
            MessageBox.Show("Enter correct days");
            return;

        }
        txtTotalEarning.Text = "";
        txtTotalIncrement.Text = "";
        txtProvidentFund.Text = "";
        txtProfessionFund.Text = "";
        txtIncomeTax.Text = "";
        txtTotalDeduction.Text = "";
        txtTotalDeduction.Text = ""; ;


        double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
        double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

        txtTotalEarning.Text = "";
        double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
        txtTotalEarning.Text = a.ToString();
        double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
        txtTotalIncrement.Text = b.ToString();

        ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
        double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

        double ee = Convert.ToDouble(txtBasicSal.Text);
        double ansEPF = (ee * d) / 100;
        txtProvidentFund.Text = ansEPF.ToString();
        professiontaxes();
     //   incometaxes();
        DataSet ds110 = new DataSet();
        ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
        if (ds110.Tables[0].Rows.Count > 0)
        {
            string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
           double asfd = Convert.ToDouble(asddf);
           int asssdf = Convert.ToInt32(asfd);
           txtIncomeTax.Text = asssdf.ToString();
        }
        else {

            System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'"+ddlEmpID.SelectedItem.ToString()+"' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
            Response.Redirect("MonthlyPaySlip.aspx");
            return;
        }
        double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
        txtTotalDeduction.Text = aa.ToString();
        double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
        txtNetSalary.Text = aaa.ToString();
        }
        catch (Exception)
        {
            MessageBox.Show("Enter Correct Month/ Invalid Data");
            Response.Redirect("MonthlyPaySlip.aspx");
        }
    }
    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        try
        {
            DataSet ds1 = new DataSet();
            ds1=aobj.sel("select * from tbl_EmpMonthlySal where Username='"+ddlEmpID.SelectedItem.Text+"' AND FinancialYear='"+ddlyear2.SelectedItem.Text+"' AND Month='"+DDlMonth.SelectedItem.Text+"'");

            if (ds1.Tables[0].Rows.Count > 0)
            {

              lblError.Text = "Data Already Exist Do you want to update then click on update button oe else cancel";
              lblError.Visible = true;
                Btnupdate.Visible = true;
              ddlyear2.Enabled = false;
              DDlMonth.Enabled = false;
              ddlEmpID.Enabled = false;
              txtConveyancy.ReadOnly = true;
              txtSpecialAllow.ReadOnly = true;
              txtOther.ReadOnly = true;
              txteffectivedays.ReadOnly = true;
              btnSubmit.Visible = false;
              btnreset.Visible = false;
              Btncancel.Visible = true;
                
            }
            else
            {


                aobj.ins("insert into tbl_EmpMonthlySal (Username,Gender,Mobile,Post,BasicSalary,HRA,DA,MedicalAllowance,TravelingAllowance,TotalEarning,Other,EmployeeProvidentFund,ProfessionalTax, IncomeTax, TotalDeductiion, NETSALARY,Name, Month, JoiningDate,FinancialYear, Conveyance, GradePay, SpecialAllowance,EffectiveDays,TotalIncrement)values('" + ddlEmpID.SelectedItem.Text.ToString() + "','" + txtGender.Text.ToString() + "'," + txtmobile.Text + ",'" + txtPost.Text.ToString() + "'," + txtBasicSal.Text + "," + txtHRA.Text + "," + txtDA.Text + "," + txtMedicalAllow.Text + "," + txtTravellAllow.Text + "," + txtTotalEarning.Text + "," + txtOther.Text + "," + txtProvidentFund.Text + "," + txtProfessionFund.Text + "," + txtIncomeTax.Text + "," + txtTotalDeduction.Text + "," + txtNetSalary.Text + ",'" + txtEmployeeName.Text + "','" + DDlMonth.SelectedItem.Text + "','" + txtJoiningDate.Text + "','" + ddlyear2.SelectedItem.Text + "'," + txtConveyancy.Text + ",'" + txtGradePay.Text + "','" + txtSpecialAllow.Text + "','" + txteffectivedays.Text + "','" + txtTotalIncrement.Text + "') ");

//                aobj.ins("insert into tbl_EmpMonthlySal(Username,Gender,Mobile,Post,BasicSalary) values ('" + ddlEmpID.SelectedItem.Text.ToString() + "','" + txtGender.Text.ToString() + "'," + txtmobile.Text + ",'" + txtPost.Text.ToString() + "'," + txtBasicSal.Text + "," + txtHRA.Text + "," + txtDA.Text + "," + txtMedicalAllow.Text + "," + txtTravellAllow.Text + "," + txtTotalEarning.Text + "," + txtOther.Text + "," +txtProvidentFund.Text+ "," + txtProfessionFund.Text + "," + txtIncomeTax.Text + "," + txtTotalDeduction.Text + "," + txtNetSalary.Text + ",'" + txtEmployeeName.Text + "','" + DDlMonth.SelectedItem.Text + "','" + txtJoiningDate.Text + "','" + ddlyear2.SelectedItem.Text + "',"+txtConveyancy.Text+","+txtSpecialAllow.Text+","+txteffectivedays.Text + ","+txtTotalIncrement.Text+","+txtGradePay.Text +")");
              //  lblError.Text = "Data Inserted Successfully";

               
                //lblError.Visible = true;
                mobile = aobj.sel("select ContactMob from tbl_EmpPrsnlDetail where Eid='" + ddlEmpID.SelectedValue + "'");
                msggg = aobj.sel("select Month, FinancialYear, NETSALARY from tbl_EmpMonthlySal where Username='" + ddlEmpID.SelectedItem.Text + "' ");
                System.Web.UI.WebControls.TextBox txtRecipientNumber = new System.Web.UI.WebControls.TextBox();
                System.Web.UI.WebControls.TextBox txtNumber = new System.Web.UI.WebControls.TextBox();
                txtNumber.Text = "8866839909";
                System.Web.UI.WebControls.TextBox txtPassword = new System.Web.UI.WebControls.TextBox();
                System.Web.UI.WebControls.TextBox txtMessage = new System.Web.UI.WebControls.TextBox();
                txtPassword.Text = "jenith";
                txtRecipientNumber.Text = mobile.Tables[0].Rows[0]["ContactMob"].ToString();

                DataSet ds1234 = new DataSet();
               ds1234= aobj.sel("select FirstName, MiddleName,Surname from tbl_EmpPrsnlDetail where Eid='" + ddlEmpID.SelectedValue + "'");

               string a = ds1234.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1234.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1234.Tables[0].Rows[0]["Surname"].ToString();
                txtMessage.Text = "Hi,'"+a+"' Please Contact to Accountant " + " For Month: " + msggg.Tables[0].Rows[0]["Month"] + " And Year: " + msggg.Tables[0].Rows[0]["FinancialYear"] + " AND Your NET SALARY is: " + msggg.Tables[0].Rows[0]["NETSALARY"] + "";

                SMS.APIType = SMSGateway.Site2SMS;
                SMS.MashapeKey = "UJgr26wtkKWMrpPR9QcSC9EHGxo2HqR5";

                SMS.Username = txtNumber.Text.Trim();

                SMS.Password = txtPassword.Text.Trim();

               // lblError.Text = "Data Inserted Successfully";
                //lblError.Visible = true;
                ddlyear2.SelectedIndex = 0;
                DDlMonth.SelectedIndex = 0;
                ddlEmpID.SelectedIndex = 0;
                txtGradePay.Text = "";
                txtEmployeeName.Text = "";
                txtJoiningDate.Text = "";
                txtEmail.Text = "";
                txtGender.Text = "";
                txtmobile.Text = "";
                txtPost.Text = "";
                txtBasicSal.Text = "";
                txtHRA.Text = "";
                txtDA.Text = "";
                txtMedicalAllow.Text = "";
                txtTravellAllow.Text = "";
                txtConveyancy.Text = "0";
                txtSpecialAllow.Text = "0";
                txtOther.Text = "0";
                txteffectivedays.Text = "0";
                txtTotalIncrement.Text = "";
                txtProvidentFund.Text = "";
                txtProfessionFund.Text = "";
                txtIncomeTax.Text = "";
                txtTotalDeduction.Text = "";
                btnreset.Visible = true;
                btnSubmit.Visible = true;
                Btnupdate.Visible = false;
                Btncancel.Visible = false;
                txtTotalEarning.Text = "";
                txtNetSalary.Text = "";


                ddlyear2.Enabled= true;
                DDlMonth.Enabled = true;
                ddlEmpID.Enabled = true;
                txtGradePay.ReadOnly = false;
                txtEmployeeName.ReadOnly = false;
                txtJoiningDate.ReadOnly = false;
                txtEmail.ReadOnly = false;
                txtGender.ReadOnly = false;
                txtmobile.ReadOnly = false;
                txtPost.ReadOnly = false;
                txtBasicSal.ReadOnly = false;
                txtHRA.ReadOnly = false;
                txtDA.ReadOnly = false;
                txtMedicalAllow.ReadOnly = false;
                txtTravellAllow.ReadOnly = false;
                txtConveyancy.ReadOnly = false;
                txtSpecialAllow.ReadOnly = false;
                txtOther.ReadOnly = false;
                txteffectivedays.ReadOnly = false;
                txtTotalIncrement.ReadOnly = false;
                txtProvidentFund.ReadOnly = false;
                txtProfessionFund.ReadOnly = false;
                txtIncomeTax.ReadOnly = false;
                txtTotalDeduction.ReadOnly = false;
                btnreset.Visible = false;
                btnSubmit.Visible = true;
                lblError.Visible = false;
                Btnupdate.Visible = false;
                Btncancel.Visible = false;
                txtTotalEarning.ReadOnly = false;
                txtNetSalary.ReadOnly = false;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Data Inserted Successfully');", true);
                if (txtRecipientNumber.Text.Trim().IndexOf(",") == -1)
                {
                    //Single SMS
                    SMS.SendSms(txtRecipientNumber.Text.Trim(), txtMessage.Text.Trim());
                }
                else
                {
                    //Multiple SMS
                    List<string> numbers = txtRecipientNumber.Text.Trim().Split(',').ToList();
                    SMS.SendSms(numbers, txtMessage.Text.Trim());
                }
            
            
            
            }
        }
        catch (Exception)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Connection Problem Or Invalid Data');", true);
          //  lblError.Text = "Connection Problem Or Invalid Data";
        }
    }
    protected void txtConveyancy_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtConveyancy.Text == "")
            {
                txtConveyancy.Text = "0";
            }
            if (txtSpecialAllow.Text == "")
            {
                txtSpecialAllow.Text = "0";
            }
            if (txtOther.Text == "")
            {
                txtOther.Text = "0";
            }
            double asdfg = Convert.ToDouble(txteffectivedays.Text);

            if (asdfg > 30)
            {
                MessageBox.Show("Enter correct days between 0 - 30");
                return;

            }
            if (asdfg < 0)
            {
                MessageBox.Show("Enter correct days");
                return;

            }
            txtTotalEarning.Text = "";
            txtTotalIncrement.Text = "";
            txtProvidentFund.Text = "";
            txtProfessionFund.Text = "";
            txtIncomeTax.Text = "";
            txtTotalDeduction.Text = "";
            txtTotalDeduction.Text = ""; ;


            double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
            double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

            txtTotalEarning.Text = "";
            double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
            txtTotalEarning.Text = a.ToString();
            double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
            Int32 ab = Convert.ToInt32(a) + Convert.ToInt32(b);
            txtTotalIncrement.Text = ab.ToString();

            ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
            double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

            double ee = Convert.ToDouble(txtBasicSal.Text);
            double ansEPF = ee / d;
            Int32 ada = Convert.ToInt32(ansEPF);
            txtProvidentFund.Text = ada.ToString();
            professiontaxes();
            // incometaxes();
            DataSet ds110 = new DataSet();
            ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
            if (ds110.Tables[0].Rows.Count > 0)
            {
                string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
                int asfd = Convert.ToInt32(asddf);
                txtIncomeTax.Text = asfd.ToString();
            }
            else
            {

                System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
                Response.Redirect("MonthlyPaySlip.aspx");
                return;
            }
            double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
            Int64 aaaa = Convert.ToInt64(aa);
            txtTotalDeduction.Text = aaaa.ToString();
            double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
            Int64 aaaaa = Convert.ToInt64(aaa);

            txtNetSalary.Text = aaaaa.ToString();
        }
        catch (Exception)
        {
            MessageBox.Show("Please Select Proper Month Invalid Days");
            Response.Redirect("MonthlyPaySlip.aspx");
        }

    }
    protected void txtSpecialAllow_TextChanged(object sender, EventArgs e)
    {
        if (txtConveyancy.Text == "")
        {
            txtConveyancy.Text = "0";
        }
        if (txtSpecialAllow.Text == "")
        {
            txtSpecialAllow.Text = "0";
        }
        if (txtOther.Text == "")
        {
            txtOther.Text = "0";
        }
        double asdfg = Convert.ToDouble(txteffectivedays.Text);

        if (asdfg > 30)
        {
            MessageBox.Show("Enter correct days");
            return;

        }
        txtTotalEarning.Text = "";
        txtTotalIncrement.Text = "";
        txtProvidentFund.Text = "";
        txtProfessionFund.Text = "";
        txtIncomeTax.Text = "";
        txtTotalDeduction.Text = "";
        txtTotalDeduction.Text = ""; ;


        double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
        double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

        txtTotalEarning.Text = "";
        double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
        txtTotalEarning.Text = a.ToString();
        double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
        txtTotalIncrement.Text = b.ToString();

        ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
        double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

        double ee = Convert.ToDouble(txtBasicSal.Text);
        double ansEPF = (ee * d) / 100;
        txtProvidentFund.Text = ansEPF.ToString();
        professiontaxes();
        //incometaxes();
        DataSet ds110 = new DataSet();
        ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
        if (ds110.Tables[0].Rows.Count > 0)
        {
            string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
            int asfd = Convert.ToInt32(asddf);
            txtIncomeTax.Text = asfd.ToString();
        }
        else
        {

            System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
            Response.Redirect("MonthlyPaySlip.aspx");
            return;
        }
        double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
        txtTotalDeduction.Text = aa.ToString();
        double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
        txtNetSalary.Text = aaa.ToString();

    }
    protected void txtOther_TextChanged(object sender, EventArgs e)
    {
        if (txtConveyancy.Text == "")
        {
            txtConveyancy.Text = "0";
        }
        if (txtSpecialAllow.Text == "")
        {
            txtSpecialAllow.Text = "0";
        }
        if (txtOther.Text == "")
        {
            txtOther.Text = "0";
        }
        double asdfg = Convert.ToDouble(txteffectivedays.Text);

        if (asdfg > 30)
        {
            MessageBox.Show("Enter correct days");
            return;

        }
        txtTotalEarning.Text = "";
        txtTotalIncrement.Text = "";
        txtProvidentFund.Text = "";
        txtProfessionFund.Text = "";
        txtIncomeTax.Text = "";
        txtTotalDeduction.Text = "";
        txtTotalDeduction.Text = ""; ;

        double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
        double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

        txtTotalEarning.Text = "";
        double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
        txtTotalEarning.Text = a.ToString();
        double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
        txtTotalIncrement.Text = b.ToString();

        ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
        double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

        double ee = Convert.ToDouble(txtBasicSal.Text);
        double ansEPF = (ee * d) / 100;
        txtProvidentFund.Text = ansEPF.ToString();
        professiontaxes();
       // incometaxes();
        DataSet ds110 = new DataSet();
        ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
        if (ds110.Tables[0].Rows.Count > 0)
        {
            string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
            int asfd = Convert.ToInt32(asddf);
            txtIncomeTax.Text = asfd.ToString();
        }
        else
        {

            System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
            Response.Redirect("MonthlyPaySlip.aspx");
            return;
        }
        double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
        txtTotalDeduction.Text = aa.ToString();
        double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
        txtNetSalary.Text = aaa.ToString();

    }

    protected void txtConveyancy_TextChanged1(object sender, EventArgs e)
    {
        try
        {
            if (txtConveyancy.Text == "")
            {
                txtConveyancy.Text = "0";
            }
            if (txtSpecialAllow.Text == "")
            {
                txtSpecialAllow.Text = "0";
            }
            if (txtOther.Text == "")
            {
                txtOther.Text = "0";
            }
            double asdfg = Convert.ToDouble(txteffectivedays.Text);

            if (asdfg > 30)
            {
                MessageBox.Show("Enter correct days");
                return;

            }
            txtTotalEarning.Text = "";
            txtTotalIncrement.Text = "";
            txtProvidentFund.Text = "";
            txtProfessionFund.Text = "";
            txtIncomeTax.Text = "";
            txtTotalDeduction.Text = "";
            txtTotalDeduction.Text = ""; ;


            double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
            double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

            txtTotalEarning.Text = "";
            double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
            txtTotalEarning.Text = a.ToString();
            double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
            txtTotalIncrement.Text = b.ToString();

            ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
            double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

            double ee = Convert.ToDouble(txtBasicSal.Text);
            double ansEPF = (ee * d) / 100;
            txtProvidentFund.Text = ansEPF.ToString();
            professiontaxes();
            //   incometaxes();
            DataSet ds110 = new DataSet();
            ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
            if (ds110.Tables[0].Rows.Count > 0)
            {
                string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
                double asfd = Convert.ToDouble(asddf);
                int asssdf = Convert.ToInt32(asfd);
                txtIncomeTax.Text = asssdf.ToString();
            }
            else
            {

                System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
                Response.Redirect("MonthlyPaySlip.aspx");
                return;
            }
            double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
            txtTotalDeduction.Text = aa.ToString();
            double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
            txtNetSalary.Text = aaa.ToString();
        }
        catch (Exception)
        {
            MessageBox.Show("Enter Correct Month");
            Response.Redirect("MonthlyPaySlip.aspx");
        }
    }
    protected void txtSpecialAllow_TextChanged1(object sender, EventArgs e)
    {
        try
        {
            if (txtConveyancy.Text == "")
            {
                txtConveyancy.Text = "0";
            }
            if (txtSpecialAllow.Text == "")
            {
                txtSpecialAllow.Text = "0";
            }
            if (txtOther.Text == "")
            {
                txtOther.Text = "0";
            }
            double asdfg = Convert.ToDouble(txteffectivedays.Text);

            if (asdfg > 30)
            {
                MessageBox.Show("Enter correct days");
                return;

            }
            txtTotalEarning.Text = "";
            txtTotalIncrement.Text = "";
            txtProvidentFund.Text = "";
            txtProfessionFund.Text = "";
            txtIncomeTax.Text = "";
            txtTotalDeduction.Text = "";
            txtTotalDeduction.Text = ""; ;


            double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
            double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

            txtTotalEarning.Text = "";
            double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
            txtTotalEarning.Text = a.ToString();
            double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
            txtTotalIncrement.Text = b.ToString();

            ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
            double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

            double ee = Convert.ToDouble(txtBasicSal.Text);
            double ansEPF = (ee * d) / 100;
            txtProvidentFund.Text = ansEPF.ToString();
            professiontaxes();
            //   incometaxes();
            DataSet ds110 = new DataSet();
            ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
            if (ds110.Tables[0].Rows.Count > 0)
            {
                string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
                double asfd = Convert.ToDouble(asddf);
                int asssdf = Convert.ToInt32(asfd);
                txtIncomeTax.Text = asssdf.ToString();
            }
            else
            {

                System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
                Response.Redirect("MonthlyPaySlip.aspx");
                return;
            }
            double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
            txtTotalDeduction.Text = aa.ToString();
            double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
            txtNetSalary.Text = aaa.ToString();
        }
        catch (Exception)
        {
            MessageBox.Show("Enter Correct Month");
            Response.Redirect("MonthlyPaySlip.aspx");
        }
    }
    protected void txtOther_TextChanged1(object sender, EventArgs e)
    {
        try
        {
            if (txtConveyancy.Text == "")
            {
                txtConveyancy.Text = "0";
            }
            if (txtSpecialAllow.Text == "")
            {
                txtSpecialAllow.Text = "0";
            }
            if (txtOther.Text == "")
            {
                txtOther.Text = "0";
            }
            double asdfg = Convert.ToDouble(txteffectivedays.Text);

            if (asdfg > 30)
            {
                MessageBox.Show("Enter correct days");
                Response.Redirect("MonthlyPaySlip.aspx");
                return;

            }
            txtTotalEarning.Text = "";
            txtTotalIncrement.Text = "";
            txtProvidentFund.Text = "";
            txtProfessionFund.Text = "";
            txtIncomeTax.Text = "";
            txtTotalDeduction.Text = "";
            txtTotalDeduction.Text = ""; ;


            double effectivedays1 = Convert.ToDouble(txtBasicSal.Text) / 30;
            double effectivedays2 = effectivedays1 * Convert.ToDouble(txteffectivedays.Text);

            txtTotalEarning.Text = "";
            double a = Convert.ToInt32(effectivedays2 + Convert.ToDouble(txtGradePay.Text) + Convert.ToDouble(txtHRA.Text) + Convert.ToDouble(txtDA.Text) + Convert.ToDouble(txtMedicalAllow.Text) + Convert.ToDouble(txtTravellAllow.Text) + Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text));
            txtTotalEarning.Text = a.ToString();
            double b = Convert.ToDouble(txtConveyancy.Text) + Convert.ToDouble(txtOther.Text) + Convert.ToDouble(txtSpecialAllow.Text);
            txtTotalIncrement.Text = b.ToString();

            ds7 = aobj.sel("select Distinct EPF from tbl_EPF");
            double d = Convert.ToDouble(ds7.Tables[0].Rows[0]["EPF"]);

            double ee = Convert.ToDouble(txtBasicSal.Text);
            double ansEPF = (ee * d) / 100;
            txtProvidentFund.Text = ansEPF.ToString();
            professiontaxes();
            //   incometaxes();
            DataSet ds110 = new DataSet();
            ds110 = aobj.sel("select DISTINCT ITPmonth from tbl_TDS where Eid=" + ddlEmpID.SelectedValue + "");
            if (ds110.Tables[0].Rows.Count > 0)
            {
                string asddf = ds110.Tables[0].Rows[0]["ITPmonth"].ToString();
                double asfd = Convert.ToDouble(asddf);
                int asssdf = Convert.ToInt32(asfd);
                txtIncomeTax.Text = asssdf.ToString();
            }
            else
            {

                System.Windows.Forms.MessageBox.Show("No Data Found In Income Tax Please tell'" + ddlEmpID.SelectedItem.ToString() + "' to Fill Income Tax Details or salary Wont Be Given.  -Thank You  SEMS TEAM");
                Response.Redirect("MonthlyPaySlip.aspx");
                return;
            }
            double aa = Convert.ToDouble(txtProvidentFund.Text) + Convert.ToDouble(txtProfessionFund.Text) + Convert.ToDouble(txtIncomeTax.Text);
            txtTotalDeduction.Text = aa.ToString();
            double aaa = Convert.ToDouble(txtTotalEarning.Text) - Convert.ToDouble(txtTotalDeduction.Text);
            txtNetSalary.Text = aaa.ToString();
        }
        catch (Exception)
        {
            MessageBox.Show("Enter Correct Month");

        }
    }
    protected void Btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            aobj.ins("update tbl_EmpMonthlySal SET Conveyance=" + txtConveyancy.Text + ", SpecialAllowance=" + txtSpecialAllow.Text + ", Other=" + txtOther.Text + ", EffectiveDays=" + txteffectivedays.Text + ", TotalEarning=" + txtTotalEarning.Text + ", TotalIncrement=" + txtTotalIncrement.Text + ", EmployeeProvidentFund=" + txtProvidentFund.Text + ", ProfessionalTax=" + txtProfessionFund.Text + ", IncomeTax=" + txtIncomeTax.Text + ",TotalDeductiion=" + txtTotalDeduction.Text + ", NETSALARY=" + txtNetSalary.Text + ",GradePay="+txtGradePay.Text+" where Username='" + ddlEmpID.SelectedItem.Text + "'");

            mobile = aobj.sel("select ContactMob from tbl_EmpPrsnlDetail where Eid='" + ddlEmpID.SelectedValue + "'");
            msggg = aobj.sel("select EffectiveDays,Month, FinancialYear, NETSALARY from tbl_EmpMonthlySal where Username='" + ddlEmpID.SelectedItem.Text + "' ");
            System.Web.UI.WebControls.TextBox txtRecipientNumber = new System.Web.UI.WebControls.TextBox();
            System.Web.UI.WebControls.TextBox txtNumber = new System.Web.UI.WebControls.TextBox();
            txtNumber.Text = "8866839909";
            System.Web.UI.WebControls.TextBox txtPassword = new System.Web.UI.WebControls.TextBox();
            System.Web.UI.WebControls.TextBox txtMessage = new System.Web.UI.WebControls.TextBox();
            txtPassword.Text = "jenith";
            txtRecipientNumber.Text = mobile.Tables[0].Rows[0]["ContactMob"].ToString();

            DataSet ds1234 = new DataSet();
            ds1234 = aobj.sel("select FirstName, MiddleName,Surname from tbl_EmpPrsnlDetail where Eid='" + ddlEmpID.SelectedValue + "'");

            string a = ds1234.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1234.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1234.Tables[0].Rows[0]["Surname"].ToString();
            txtMessage.Text = "Hi,'" + a + "' Please Collect Salary of Month: '" + msggg.Tables[0].Rows[0]["Month"].ToString() + "' , Year: '" + msggg.Tables[0].Rows[0]["FinancialYear"].ToString() + "' AND Your NET SALARY is: '" + msggg.Tables[0].Rows[0]["NETSALARY"].ToString() +"' For days: '" +msggg.Tables[0].Rows[0]["EffectiveDays"]+"' -Thank You SEMS Team";

            SMS.APIType = SMSGateway.Site2SMS;
            SMS.MashapeKey = "UJgr26wtkKWMrpPR9QcSC9EHGxo2HqR5";

            SMS.Username = txtNumber.Text.Trim();

            SMS.Password = txtPassword.Text.Trim();

            // lblError.Text = "Data Inserted Successfully";
            //lblError.Visible = true;
            ddlyear2.SelectedIndex = 0;
            DDlMonth.SelectedIndex = 0;
            ddlEmpID.SelectedIndex = 0;
            txtGradePay.Text = "";
            txtEmployeeName.Text = "";
            txtJoiningDate.Text = "";
            txtEmail.Text = "";
            txtGender.Text = "";
            txtmobile.Text = "";
            txtPost.Text = "";
            txtBasicSal.Text = "";
            txtHRA.Text = "";
            txtDA.Text = "";
            txtMedicalAllow.Text = "";
            txtTravellAllow.Text = "";
            txtConveyancy.Text = "0";
            txtSpecialAllow.Text = "0";
            txtOther.Text = "0";
            txteffectivedays.Text = "0";
            txtTotalIncrement.Text = "";
            txtProvidentFund.Text = "";
            txtProfessionFund.Text = "";
            txtIncomeTax.Text = "";
            txtTotalDeduction.Text = "";
            btnreset.Visible = true;
            btnSubmit.Visible = true;
            Btnupdate.Visible = false;
            Btncancel.Visible = false;
            txtTotalEarning.Text = "";
            txtNetSalary.Text = "";



            ddlyear2.Enabled = true;
            DDlMonth.Enabled = true;
            ddlEmpID.Enabled = true;
            txtGradePay.ReadOnly = false;
            txtEmployeeName.ReadOnly = false;
            txtJoiningDate.ReadOnly = false;
            txtEmail.ReadOnly = false;
            txtGender.ReadOnly = false;
            txtmobile.ReadOnly = false;
            txtPost.ReadOnly = false;
            txtBasicSal.ReadOnly = false;
            txtHRA.ReadOnly = false;
            txtDA.ReadOnly = false;
            txtMedicalAllow.ReadOnly = false;
            txtTravellAllow.ReadOnly = false;
            txtConveyancy.ReadOnly = false;
            txtSpecialAllow.ReadOnly = false;
            txtOther.ReadOnly = false;
            txteffectivedays.ReadOnly = false;
            txtTotalIncrement.ReadOnly = false;
            txtProvidentFund.ReadOnly = false;
            txtProfessionFund.ReadOnly = false;
            txtIncomeTax.ReadOnly = false;
            txtTotalDeduction.ReadOnly = false;
            btnreset.Visible = false;
            btnSubmit.Visible = true;
            lblError.Visible = false;
            Btnupdate.Visible = false;
            Btncancel.Visible = false;
            txtTotalEarning.ReadOnly = false;
            txtNetSalary.ReadOnly = false;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Data Updated Successfully');", true);
            if (txtRecipientNumber.Text.Trim().IndexOf(",") == -1)
            {
                //Single SMS
                SMS.SendSms(txtRecipientNumber.Text.Trim(), txtMessage.Text.Trim());
            }
            else
            {
                //Multiple SMS
                List<string> numbers = txtRecipientNumber.Text.Trim().Split(',').ToList();
                SMS.SendSms(numbers, txtMessage.Text.Trim());
            }
            
            
            
            
            
            
            
            
            //lblError.Text = ""+ddlEmpID.SelectedItem.Text+" Updated Successfully";

           // Response.Redirect(@"~\AdminPrincipalPanel\MonthlyPaySlip.aspx");
        }
        catch (Exception ex)
        {
            lblError.Text = "There Is A problem";
        }
       // Response.Redirect(@"~\AdminPrincipalPanel\MonthlyPaySlip.aspx"); 
    }
    protected void Btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~\AdminPrincipalPanel\MonthlyPaySlip.aspx");
    }
}
    