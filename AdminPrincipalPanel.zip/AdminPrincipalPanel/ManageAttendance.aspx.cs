﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Windows.Forms;

public partial class AdminPrincipalPanel_ManageAttendance : System.Web.UI.Page
{
    SqlConnection con;
    DataSet ds1 = new DataSet();
    Attendance aObj = new Attendance();
    protected void Page_Load(object sender, EventArgs e)
    {
        //Txtdate_CalendarExtender.EndDate = DateTime.Now;
        con = new SqlConnection();

        con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEMSConnectionString"].ToString();

        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!IsPostBack)
        {
            FillAtt();
            if (Request.QueryString["Id"] != null)
            {
                ViewState["Id"] = Request.QueryString["Id"];
                FillData();

                Btnsave.Text = "Update";

            }
            else
            {
                Btnsave.Text = "Save";

            }
        }
        
    }

    protected void Ddlusername_SelectedIndexChanged2(object sender, EventArgs e)
    {
        ds1 = aObj.sele("select Eid, FirstName,MiddleName, Surname from tbl_EmpPrsnlDetail where Eid ='" + Ddlusername.SelectedValue.ToString() + "'");
        lblname.Text = "<b>Employee Id=</b>" + ds1.Tables[0].Rows[0]["Eid"] + " " + "<b>Name=</b>" + ds1.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1.Tables[0].Rows[0]["Surname"].ToString();
        lblname.Visible = true;

        SqlCommand cmd = new SqlCommand("  SELECT Distinct  tbl_Attendance.Id, tbl_EmpPrsnlDetail.UserName AS UserName,tbl_Attendance.Date, tbl_Attendance.AttendanceType FROM  tbl_Attendance INNER JOIN tbl_EmpPrsnlDetail ON tbl_Attendance.Eid = tbl_EmpPrsnlDetail.Eid WHERE  (tbl_EmpPrsnlDetail.UserName = '" + Ddlusername.SelectedItem.Text + "')", con);

      //SqlCommand cmd = new SqlCommand("SELECT tbl_Attendance.Id, tbl_EmpPrsnlDetail.UserName AS Expr1,   date(tbl_Attendance.Date),   tbl_Attendance.AttendanceType         DATEPART(dd, tbl_Attendance.Date) AS Day, MONTH(tbl_Attendance.Date) AS Month, YEAR(tbl_Attendance.Date) AS Year                                                                    FROM            tbl_Attendance INNER JOIN  tbl_EmpPrsnlDetail ON tbl_Attendance.Eid = tbl_EmpPrsnlDetail.Eid WHERE        (tbl_EmpPrsnlDetail.UserName = '"+Ddlusername.SelectedItem.Text+"')",con); 
        SqlDataAdapter myadr = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        myadr.Fill(dt);

        gv_city.DataSource = dt;
        
        gv_city.DataBind();
    

    }



    protected void Btnsave_Click(object sender, EventArgs e)
    {




        if (ViewState["Id"] != null)
        {
            UpdateAtt();

            FillAtt();

            //Response.Write("<script>alert('Update Successfully')</script>");
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Update Successfully');", true);
            Ddlusername.SelectedIndex = 0;
            Txtdate.Text = "";
            ddlatt.SelectedIndex = 0;

            //           s_dropdown1.SelectedIndex = 0;
            Btnsave.Text = "Save";
            ViewState["Id"] = null;

        }
        else
        {
             aObj._eid = Convert.ToInt32(Ddlusername.SelectedValue);
            //DateTime x = new DateTime();
        //x = Convert.ToDateTime(Txtdate.Text);
        //string s;
        //s = "MM DD YYYY";

       // MessageBox.Show(x.ToString("d"));
 
  
        //
       //aObj._adate = x.Date.ToShortDateString() ;
        //string dt = x.Date.ToShortDateString();
       string str = "select * from tbl_Attendance where Eid=" + aObj._eid + " And Date='" + Txtdate.Text + "'";
       SqlDataAdapter da = new SqlDataAdapter(str, con);
                DataSet ds = new DataSet();
                da.Fill(ds);

                if (ds.Tables[0].Rows.Count == 0)
                {
                    insertAtt();
                    FillAtt();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('EMPLOYEE ATTENDNECE ALREADY EXISTS');", true);
                    
                }

            

        }


    }

    void FillAtt()
    {
        gv_city.DataSource = aObj.GetAttList();
        gv_city.DataBind();
    }

    public void UpdateAtt()
    {
        //aObj._eid = Convert.ToInt32(Ddlusername.SelectedValue);
        
        
        //aObj._adate = Convert.ToDateTime(Txtdate.Text);
        //string var12 = aObj._adate.ToString();
        //var12.TrimEnd(var12[12]);
        //aObj._atype = ddlatt.SelectedItem.Value.ToString();
        //aObj._Id = Convert.ToInt32(HiddenField1.Value);
        ////  aObj._Id = Convert.ToInt32();
        //ViewState["Id"] = aObj.UpdateAttList();
        aObj._eid = Convert.ToInt32(Ddlusername.SelectedValue);
        aObj._adate = Txtdate.Text.ToString();
        aObj._atype = ddlatt.SelectedItem.Value.ToString();
        aObj._Id = Convert.ToInt32(HiddenField1.Value);
        //  aObj._Id = Convert.ToInt32();
        ViewState["Id"] = aObj.UpdateAttList();

    }


    void insertAtt()
    {



       // char var12[] = {1,2,0,:,A,M}
        aObj._eid = Convert.ToInt32(Ddlusername.SelectedValue);
       // DateTime x = new DateTime();
       // x = Convert.ToString(Txtdate.Text);
       // string s;
       // s = "MM DD YYYY";

       //// MessageBox.Show(x.ToString("d"));
 
  
        //x.Date
        aObj._adate = Convert.ToString(Txtdate.Text);

        aObj._atype = ddlatt.SelectedItem.Value.ToString();


        int r = 0;

        r = aObj.insertAtt();
        // Response.Write("<script>alert('Inserted Successfully')</script>");
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        Ddlusername.SelectedIndex = 0;
        Txtdate.Text = "";
        ddlatt.SelectedIndex = 0;
        // c_dropdown1.SelectedIndex = 0;
    }

    protected void gv_city_row_cmd(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "cmdEdit")
        {
            Response.Redirect("ManageAttendance.aspx?id=" + e.CommandArgument);
        }

    }

    protected void FillData()
    {

        aObj.GetAttbyPK(Convert.ToInt32(ViewState["Id"]));

        Ddlusername.SelectedValue = aObj._eid.ToString();
        Txtdate.Text = aObj._adate.ToString();
        ddlatt.SelectedValue = aObj._atype.ToString();
        HiddenField1.Value = aObj._Id.ToString();

    }
    protected void Txtdate_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DateTime d = Convert.ToDateTime(Txtdate.Text);

            if (d > System.DateTime.Now)
            {
                Label1.Visible = true;
            }
            else
            {
                Label1.Visible = false;
            }
        }
        catch (Exception)
        {
            Label1.Visible = true;
        }
    }
    protected void grid_Att_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
   

    protected void Ddlusername_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ddl.DataSource = ds1;
        //ddl.DataTextField = "FirstName";
        //ddl.DataValueField = "FirstName";
        //ddl.DataBind();
        //ddl.Items.Insert(0, new ListItem("--Select--", "0"));
      
    }

    protected void gv_city_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
    }
}