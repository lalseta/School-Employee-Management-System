﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin : System.Web.UI.MasterPage
{
    IUDS Aobj = new IUDS();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["new"] != null)
            {
                Label1.Visible = true;
                Label1.Text = Session["new"].ToString();

                DataSet ds123 = new DataSet();
                string a = Session["new"].ToString();
                ds123 = Aobj.sel("select DesignationId from tbl_EmpPrsnlDetail where UserName='" + a + "'");
                int asd = Convert.ToInt16(ds123.Tables[0].Rows[0]["DesignationId"]);
                if (asd == 6)
                {
                    Label2.Text = "Admin Panel";

                }
                else
                {
                    Label2.Text = "Principal Panel";
                    Panel1.Visible = true;
                }
            }
            else
            {
                Response.Redirect("../Login.aspx");
            }
        }

        catch (Exception)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Please Relogin Problem In Internet Connection');", true);
            Response.Redirect("../Login.aspx");
        }
    }
}