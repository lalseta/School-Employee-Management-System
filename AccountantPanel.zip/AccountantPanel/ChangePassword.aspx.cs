﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class AccountantPanel_ChangePassword : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["new"] == null)
        {
            Response.Redirect("login.aspx");
        }
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

    }
    protected void Btnchangepwd_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = "update tbl_EmpPrsnlDetail set Password='" + Txtnewpass.Text + "'where UserName='" + Session["new"].ToString() + "' and Password='" + Txtpass.Text + "'";
            cmd.Connection = cn;
            cmd.ExecuteNonQuery();
            IfError.Text = "Your Password Has been Modified";
            IfError.Visible = true;

        }
        catch (Exception)
        {
            IfError.Text = "Please Enter Correct Password";
            IfError.Visible = true;

        }
    }
    
}