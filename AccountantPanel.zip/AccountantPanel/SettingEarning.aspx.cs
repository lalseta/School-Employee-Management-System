﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Threading;



public partial class Accountant_SettingEarning : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();

    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();

    IUDS aobj = new IUDS();
    pservice p = new pservice();
    dataservices ds = new dataservices();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT [DesignationId], [DesignationName] FROM [tbl_Designation] WHERE (([DesignationId] <> 1) AND ([DesignationId] <> 6)) ORDER BY [DesignationId]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlMA.DataSource = ds;
            ddlMA.DataTextField = "DesignationName";
            ddlMA.DataValueField = "DesignationId";
            ddlMA.DataBind();
            ddlMA.Items.Insert(0, "-----Select-----");

            ddlHRA.DataSource = ds;
            ddlHRA.DataTextField = "DesignationName";
            ddlHRA.DataValueField = "DesignationId";
            ddlHRA.DataBind();
            ddlHRA.Items.Insert(0, "-----Select-----");

            ddlTA.DataSource = ds;
            ddlTA.DataTextField = "DesignationName";
            ddlTA.DataValueField = "DesignationId";
            ddlTA.DataBind();
            ddlTA.Items.Insert(0, "-----Select-----");

            //fillda();
            //fillhra();
            //fillma();
            //fillta();

           aobj.FillGrid("select * from tbl_DA", GridView5);
           aobj.FillGrid("SELECT tbl_MedicalAllow.id,tbl_MedicalAllow.MedicalAllowance, tbl_MedicalAllow.AcademicYear, tbl_MedicalAllow.FromMonth, tbl_MedicalAllow.ToMonth, tbl_Designation.DesignationName FROM tbl_MedicalAllow INNER JOIN tbl_Designation ON tbl_MedicalAllow.DesignationId = tbl_Designation.DesignationId", GridView1);
           aobj.FillGrid("SELECT tbl_TA.id, tbl_TA.TravellingAllowance, tbl_TA.DesignationId, tbl_TA.AcademicYear, tbl_TA.FromMonth, tbl_TA.ToMonth, tbl_Designation.DesignationName FROM tbl_TA INNER JOIN tbl_Designation ON tbl_TA.DesignationId = tbl_Designation.DesignationId", GridView2);

            aobj.FillGrid("SELECT tbl_HRA.id, tbl_HRA.HRA, tbl_HRA.AcademicYear, tbl_HRA.FromDate, tbl_HRA.ToDate,tbl_HRA.DesignationId, tbl_Designation.DesignationName FROM tbl_HRA INNER JOIN  tbl_Designation ON tbl_HRA.DesignationId = tbl_Designation.DesignationId", GridView3);

        }

    }

    //public void fillda()
    //{
    //    GridView1.DataSource=ds.fillda(p);
    //    GridView1.DataBind();
    //}


    //public void fillma()
    //{
    //    GridView2.DataSource = ds.fillma(p);
    //    GridView2.DataBind();
    //}

    //public void fillhra()
    //{
    //    GridView3.DataSource = ds.fillhra(p);
    //    GridView3.DataBind();
    //}


    //public void fillta()
    //{
    //    GridView4.DataSource = ds.fillta(p);
    //    GridView4.DataBind();
    //}



    protected void btnHRA_Click(object sender, EventArgs e)
    {
        ds1 = aobj.sel("select * from tbl_HRA where AcademicYear = '" + ddlyear1.SelectedValue + "' AND DesignationId= '" + ddlHRA.SelectedValue + "'  ");
        if (ds1.Tables[0].Rows.Count > 0)
        {
            System.Windows.Forms.MessageBox.Show("HRA of Year '" + ddlyear1.SelectedValue + "' Already Exist");
        //    gridHRA();
            return;
        }
        else
        {
            try
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "HRA";
                cmd.Parameters.AddWithValue("@HRA", txtHRA.Text);
                cmd.Parameters.AddWithValue("@AcademicYear", ddlyear1.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@DesignationId", ddlHRA.SelectedValue);


                cmd.ExecuteNonQuery();

                lblHra.Text = "Staff HRA Inserted Successfully";
                lblHra.Visible = true;
          //      gridHRA();
                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }

            catch (Exception)
            {
                lblHra.Text = "Problem with Database";
                lblHra.Visible = true;
                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            finally
            {
                conn.Close();
            //    gridHRA();
            }
        }
    }

    protected void btnDA_Click(object sender, EventArgs e)
    {

        ds1 = aobj.sel("select * from tbl_DA where AcademicYear = '" + ddlyear.SelectedValue + "'  ");
        if (ds1.Tables[0].Rows.Count > 0)
        {
            System.Windows.Forms.MessageBox.Show("DA of Year '" + ddlyear.SelectedValue + "' Already Exist");
            //gridDA();
            return;
        }
        else
        {
            try
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DA";

                cmd.Parameters.AddWithValue("@DA", txtDA.Text);

                cmd.Parameters.AddWithValue("@AcademicYear", ddlyear.SelectedValue);

                cmd.ExecuteNonQuery();

                lblDA.Text = "Staff HRA Inserted Successfully";
                lblDA.Visible = true;
                //gridDA();

                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }

            catch (Exception)
            {
                lblDA.Text = "Problem with Database";
                lblDA.Visible = true;
                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            finally
            {
                conn.Close();
                //gridDA();
            }

        }
    }
    //void gridDA()
    //{

    //    da = new SqlDataAdapter("select * from tbl_DA", conn);

    //    DataTable dt = new DataTable();
    //    da.Fill(dt);

    //    GridView1.DataSource = dt;
    //    GridView1.DataBind();
    //}
    protected void btnMA_Click(object sender, EventArgs e)
    {
        ds1 = aobj.sel("select * from tbl_MedicalAllow where AcademicYear = '" + ddlyear0.SelectedValue + "'  ");
        if (ds1.Tables[0].Rows.Count > 0)
        {
            System.Windows.Forms.MessageBox.Show("MedicalAllowance of Year '" + ddlyear0.SelectedValue + "' Already Exist");
            //gridMA();
            return;
        }
        else
        {
            try
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MedicalAllowance";

                cmd.Parameters.AddWithValue("@MedicalAllowance", txtMA.Text);

                cmd.Parameters.AddWithValue("@AcademicYear", ddlyear0.SelectedValue);
                cmd.Parameters.AddWithValue("@DesignationId", ddlMA.SelectedValue);
                cmd.ExecuteNonQuery();

                lblMA.Text = "Staff MA Inserted Successfully";
                lblMA.Visible = true;
              //  gridMA();

                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            catch (Exception)
            {
                lblMA.Text = "Problem with Database";
                lblMA.Visible = true;
                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            finally
            {
                conn.Close();
                //gridMA();
            }
        }
    }
    //void gridMA()
    //{

    //    da = new SqlDataAdapter("SELECT tbl_MedicalAllow.AcademicYear, tbl_MedicalAllow.MedicalAllowance, tbl_Designation.DesignationName FROM tbl_MedicalAllow INNER JOIN tbl_Designation ON tbl_MedicalAllow.DesignationId = tbl_Designation.DesignationId", conn);

    //    DataTable dt = new DataTable();
    //    da.Fill(dt);

    //    GridView2.DataSource = dt;
    //    GridView2.DataBind();
    //}
    //protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    GridView2.EditIndex = e.NewEditIndex;
    //    int index = GridView2.EditIndex;
    //    GridViewRow row = GridView2.Rows[index];
    //    int Id = Convert.ToInt16(GridView2.DataKeys[row.RowIndex].Value.ToString());
    //    gridMA();
    //}

    //protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    //{
    //    int index = GridView2.EditIndex;

    //    GridViewRow row = GridView2.Rows[index];
    //    int Id = Convert.ToInt16(GridView2.DataKeys[row.RowIndex].Value.ToString());

    //    TextBox txtMA = (TextBox)GridView2.Rows[e.RowIndex].Cells[3].Controls[0];
    //    // TextBox da = (TextBox)GridView2.Rows[e.RowIndex].Cells[5].Controls[0];


    //    cmd = new SqlCommand();
    //    cmd.CommandText = "update tbl_MedicalAllow set MedicalAllowance='" + txtMA.Text + "' where Id='" + Id + "'";
    //    cmd.Connection = conn;
    //    cmd.ExecuteNonQuery();

    //    GridView2.EditIndex = -1;
    //    gridMA();
    //}
    protected void btnTA_Click(object sender, EventArgs e)
    {
        ds1 = aobj.sel("select * from tbl_TA where AcademicYear = '" + ddlyear2.SelectedValue + "'AND DesignationId = '" + ddlTA.SelectedValue + "'  ");
        if (ds1.Tables[0].Rows.Count > 0)
        {
            System.Windows.Forms.MessageBox.Show("TA of Year '" + ddlyear2.SelectedValue + "' Already Exist");
            //gridTA();
            return;
        }
        else
        {
            try
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TA";

                cmd.Parameters.AddWithValue("@TravellingAllowance", txtTA.Text);
                cmd.Parameters.AddWithValue("@DesignationId", ddlTA.SelectedValue);
                cmd.Parameters.AddWithValue("@AcademicYear", ddlyear2.SelectedValue);

                cmd.ExecuteNonQuery();

                lblMA.Text = "Staff TravellingAllowance Inserted Successfully";
                lblMA.Visible = true;
                //  gridTA();

                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            catch (Exception)
            {
                lblTA.Text = "Problem with Database";
                lblTA.Visible = true;
                // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
            }
            finally
            {
                conn.Close();
                //gridTA();
            }
        }
    }
    //}
    //void gridTA()
    //{

    //    da = new SqlDataAdapter("SELECT tbl_Designation.DesignationName, tbl_TA.AcademicYear, tbl_TA.TravellingAllowance FROM tbl_Designation INNER JOIN tbl_TA ON tbl_Designation.DesignationId = tbl_TA.DesignationId", conn);

    //    DataTable dt = new DataTable();
    //    da.Fill(dt);

    //    GridView4.DataSource = dt;
    //    GridView4.DataBind();
    //}



    protected void GridView5_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            GridView5.EditIndex = e.NewEditIndex;
            int index = GridView5.EditIndex;
            GridViewRow row = GridView5.Rows[index];
            int id = Convert.ToInt16(GridView5.DataKeys[row.RowIndex].Value.ToString());
            aobj.FillGrid("select * from tbl_DA", GridView5);
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView5_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int index = GridView5.EditIndex;
            GridViewRow row = GridView5.Rows[index];
            int id = Convert.ToInt16(GridView5.DataKeys[row.RowIndex].Value.ToString());
            TextBox txtDA = (TextBox)GridView5.Rows[e.RowIndex].Cells[1].Controls[0];

            cmd = new SqlCommand();
           
                cmd.CommandText = "update tbl_DA set DA = '" + txtDA.Text + "' where id = '" + id + "'";
                conn.Open();
                cmd.Connection = conn;
                    
                cmd.ExecuteNonQuery();

                GridView5.EditIndex = -1;
                aobj.FillGrid("select * from tbl_DA", GridView5);
           

        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            GridView1.EditIndex = e.NewEditIndex;
            int index = GridView1.EditIndex;
            GridViewRow row = GridView1.Rows[index];
            int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
          //  aobj.FillGrid("SELECT tbl_MedicalAllow.MedicalAllowance, tbl_MedicalAllow.AcademicYear, tbl_MedicalAllow.FromMonth, tbl_MedicalAllow.ToMonth, tbl_Designation.DesignationName FROM tbl_MedicalAllow INNER JOIN tbl_Designation ON tbl_MedicalAllow.DesignationId = tbl_Designation.DesignationId ", GridView1);

            aobj.FillGrid("SELECT tbl_MedicalAllow.id,tbl_MedicalAllow.MedicalAllowance, tbl_MedicalAllow.AcademicYear, tbl_MedicalAllow.FromMonth, tbl_MedicalAllow.ToMonth, tbl_Designation.DesignationName FROM tbl_MedicalAllow INNER JOIN tbl_Designation ON tbl_MedicalAllow.DesignationId = tbl_Designation.DesignationId ", GridView1);
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int index = GridView1.EditIndex;
            GridViewRow row = GridView1.Rows[index];
            int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
            TextBox txtMA = (TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0];
            
            cmd = new SqlCommand();

            cmd.CommandText = "update tbl_MedicalAllow set MedicalAllowance = '" + txtMA.Text + "' where id = '" + id + "'";
            conn.Open();
            cmd.Connection = conn;

            cmd.ExecuteNonQuery();

            GridView1.EditIndex = -1;
            aobj.FillGrid("SELECT tbl_MedicalAllow.id, tbl_MedicalAllow.MedicalAllowance, tbl_MedicalAllow.AcademicYear, tbl_MedicalAllow.FromMonth, tbl_MedicalAllow.ToMonth, tbl_Designation.DesignationName FROM tbl_MedicalAllow INNER JOIN tbl_Designation ON tbl_MedicalAllow.DesignationId = tbl_Designation.DesignationId ", GridView1);


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }

    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {
         try
        {
            GridView2.EditIndex = e.NewEditIndex;
            int index = GridView2.EditIndex;
            GridViewRow row = GridView2.Rows[index];
            int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
            aobj.FillGrid("SELECT tbl_TA.id, tbl_TA.TravellingAllowance, tbl_TA.AcademicYear, tbl_TA.FromMonth, tbl_TA.ToMonth, tbl_Designation.DesignationName FROM tbl_TA INNER JOIN tbl_Designation ON tbl_TA.DesignationId = tbl_Designation.DesignationId ", GridView2);
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int index = GridView2.EditIndex;
            GridViewRow row = GridView2.Rows[index];
            int id = Convert.ToInt16(GridView2.DataKeys[row.RowIndex].Value.ToString());
            TextBox txtMA = (TextBox)GridView2.Rows[e.RowIndex].Cells[1].Controls[0];
            
            cmd = new SqlCommand();

            cmd.CommandText = "update tbl_TA set TravellingAllowance = '" + txtMA.Text + "' where id = '" + id + "'";
            conn.Open();
            cmd.Connection = conn;

            cmd.ExecuteNonQuery();

            GridView2.EditIndex = -1;
            aobj.FillGrid("SELECT tbl_TA.id, tbl_TA.TravellingAllowance, tbl_TA.DesignationId, tbl_TA.AcademicYear, tbl_TA.FromMonth, tbl_TA.ToMonth, tbl_Designation.DesignationName FROM tbl_TA INNER JOIN tbl_Designation ON tbl_TA.DesignationId = tbl_Designation.DesignationId", GridView2);


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
    {

        try
        {
            GridView3.EditIndex = e.NewEditIndex;
            int index = GridView3.EditIndex;
            GridViewRow row = GridView3.Rows[index];
            int id = Convert.ToInt16(GridView3.DataKeys[row.RowIndex].Value.ToString());
            aobj.FillGrid("SELECT tbl_HRA.id, tbl_HRA.HRA, tbl_HRA.AcademicYear, tbl_HRA.FromDate, tbl_HRA.ToDate, tbl_Designation.DesignationName FROM tbl_HRA INNER JOIN  tbl_Designation ON tbl_HRA.DesignationId = tbl_Designation.DesignationId ", GridView3);
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void GridView3_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int index = GridView3.EditIndex;
            GridViewRow row = GridView3.Rows[index];
            int id = Convert.ToInt16(GridView3.DataKeys[row.RowIndex].Value.ToString());
            TextBox txtMA = (TextBox)GridView3.Rows[e.RowIndex].Cells[1].Controls[0];

            cmd = new SqlCommand();

            cmd.CommandText = "update tbl_HRA set HRA = '" + txtMA.Text + "' where id = '" + id + "'";
            conn.Open();
            cmd.Connection = conn;

            cmd.ExecuteNonQuery();

            GridView3.EditIndex = -1;
            aobj.FillGrid("SELECT tbl_HRA.id, tbl_HRA.HRA, tbl_HRA.AcademicYear, tbl_HRA.FromDate, tbl_HRA.ToDate, tbl_Designation.DesignationName FROM tbl_HRA INNER JOIN  tbl_Designation ON tbl_HRA.DesignationId = tbl_Designation.DesignationId", GridView3);


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
   
}