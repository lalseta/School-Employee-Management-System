﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class AccountantPanel_StaffSalary : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    
    DataSet ds1 = new DataSet();
   
    IUDS aobj = new IUDS();
    protected void Page_Load(object sender, EventArgs e)
    {
        grid();
        
        if (!IsPostBack)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT [Eid], [UserName] FROM [tbl_EmpPrsnlDetail] WHERE (([DesignationId] <> 1) AND ([DesignationId] <> 6) AND ([DesignationId] <> 5)) ORDER BY [Eid]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlEmpId.DataSource = ds;
            ddlEmpId.DataTextField = "UserName";
            ddlEmpId.DataValueField = "Eid";
            ddlEmpId.DataBind();
            ddlEmpId.Items.Insert(0, "-----Select-----");
        }

    }
    public void grid()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT tbl_BasicSalary.Eid AS EmployeeID, tbl_EmpPrsnlDetail.FirstName, tbl_EmpPrsnlDetail.MiddleName, tbl_EmpPrsnlDetail.Surname, tbl_BasicSalary.AcademicYear, tbl_BasicSalary.BasicSalary, tbl_BasicSalary.GradePay , tbl_Designation.DesignationName As Post FROM tbl_EmpPrsnlDetail INNER JOIN tbl_BasicSalary ON tbl_EmpPrsnlDetail.Eid = tbl_BasicSalary.Eid INNER JOIN tbl_Designation ON tbl_EmpPrsnlDetail.DesignationId = tbl_Designation.DesignationId", conn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
 //       this.GridView1.Columns[6].Visible = false;
       // GridView1.Columns[0].Visible = false;


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

       //if (conn.State == ConnectionState.Open)
        //{
        //    conn.Close();


        //}
        //else
        //{
        //    conn.Open();
        //}
        //conn.Open();


        ds1 = aobj.sel("select * from tbl_BasicSalary where Eid = '" + ddlEmpId.SelectedValue + "' AND AcademicYear = '"+ ddlyear.SelectedValue +"'  ");
        if (ds1.Tables[0].Rows.Count > 0)
        {
            System.Windows.Forms.MessageBox.Show("Data  Already Exist for "+ds1.Tables[0].Rows[0]["Eid"]+". So Please Donot Repeat");
            return;
        }
        else
        {
            try
            {

                conn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True";
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SpBasicSalary";
                cmd.Parameters.AddWithValue("@Eid", ddlEmpId.SelectedValue);
                cmd.Parameters.AddWithValue("@AcademicYear", ddlyear.SelectedValue);
                cmd.Parameters.AddWithValue("@BasicSalary", txtbasicsalary.Text);
                cmd.Parameters.AddWithValue("@GradePay", txtgradepay.Text);

                cmd.ExecuteNonQuery();

                lbliferror.Text = "Salary Inserted";
                lbliferror.Visible = true;
                conn.Close();
                txtbasicsalary.Text = "";
                ddlEmpId.SelectedIndex = 0;
            }
            catch (Exception)
            {
                lbliferror.Text = "Please Enter Correct Data";
            }
        }
        //finally
        //{

        //    conn.Close();
        //}

    }
    protected void ddlEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ds1 = aobj.sel("select Eid, FirstName, MiddleName, Surname,JoiningDate,DesignationId from tbl_EmpPrsnlDetail where Eid ='" + ddlEmpId.SelectedValue + "'");
        //select DISTINCT a.PatientId,b.PatientName from tblBillingMaster a join tblRegistrationMaster b on a.PatientId=b.PatientId where a.paid=1
        ds1 = aobj.sel("select DISTINCT a.Eid, a.FirstName, a.MiddleName, a.Surname, a.JoiningDate, a.DesignationId, b.DesignationName from tbl_EmpPrsnlDetail a join tbl_Designation b on a.DesignationId=b.DesignationId where Eid ='" + ddlEmpId.SelectedValue + "'");

        if (ds1.Tables[0].Rows.Count > 0)
        {
            lblName.Text = " " + ds1.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds1.Tables[0].Rows[0]["MiddleName"].ToString() + " " + ds1.Tables[0].Rows[0]["Surname"].ToString();
            lblName.Visible = true;
            lblJoiningDate.Text = "" + ds1.Tables[0].Rows[0]["JoiningDate"].ToString();
            lblJoiningDate.Visible = true;
            string designate = (string)ds1.Tables[0].Rows[0]["DesignationName"];
            lblPost.Text = designate;
            lblPost.Visible = true;
            
        }
      
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        pnlshowdata.Visible = true;

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex=e.NewPageIndex;
            grid();
    }
}