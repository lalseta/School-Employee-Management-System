﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
//using System.Windows.Forms;

public partial class AccountantPanel_SeetingsDeduction : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|SEMSDatabase.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();

    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();
    pservice p = new pservice();
    IUDS aobj = new IUDS();
    dataservices ds = new dataservices();
    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
        fillpt();
        fillit();
    }
    public void fillgrid()
    {
        GridView1.DataSource = ds.fillepf(p);
        GridView1.DataBind();
    }

    public void fillpt()
    {
        GridView2.DataSource = ds.fillpt(p);
        GridView2.DataBind();
 
    }

    public void fillit()
    {
        GridView3.DataSource = ds.fillit(p);
        GridView3.DataBind();

    }
    

    protected void btnEPF_Click(object sender, EventArgs e)
    {
        
        
        ds1.Clear();
        DataSet dssel = new DataSet();
        dssel = aobj.sel("select Id, AcademicYear from tbl_EPF where AcademicYear='" + ddlyear.SelectedValue + "' AND FromMonth='" + DDlMonth.SelectedValue + "' AND ToMonth='"+DDlMonth0.SelectedValue+"'");
        if (dssel.Tables[0].Rows.Count > 0)
    {
        aobj.ins("update tbl_EPF set EPF='"+txtEPF.Text+"', AcademicYear='" + ddlyear.SelectedValue + "' , FromMonth='" + DDlMonth.SelectedValue + "' , ToMonth='" + DDlMonth0.SelectedValue + "' where Id='"+dssel.Tables[0].Rows[0]["Id"].ToString()+"' ");
       
        lblEPF.Text = "Data Already Exits for Year '" + ddlyear.SelectedValue + "' And Now Successfully updated to '"+txtEPF.Text+"'";
        lblEPF.Visible=true;
        fillgrid();
            return;
    }
    else
    {

        try
        {
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spEPF";
            cmd.Parameters.AddWithValue("@EPF", txtEPF.Text.ToString());
            cmd.Parameters.AddWithValue("@AcademicYear", ddlyear.SelectedValue);
            cmd.Parameters.AddWithValue("@FromMonth", DDlMonth.SelectedValue);
            cmd.Parameters.AddWithValue("@ToMonth", DDlMonth0.SelectedValue);



            cmd.ExecuteNonQuery();

            lblEPF.Text = "Staff EPF Inserted Successfully for Year'" + ddlyear.SelectedValue + "'";
            lblEPF.Visible = true;
            fillgrid();
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        catch (Exception)
        {
            lblEPF.Text = "Problem with Database";
            lblEPF.Visible = true;
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        finally
        {
            conn.Close();
            txtEPF.Text = "";
            ddlyear.SelectedIndex = 0;
        }

    }
    }
    

    protected void Button2_Click(object sender, EventArgs e)
    {
        ds1.Clear();
        ds1 = aobj.sel("select Id, AcademicYear from tbl_ProfessionalTax where AcademicYear='" + ddlyear0.SelectedValue + "'  AND FromMonth='"+DDlMonth1.SelectedValue+"' AND ToMonth='"+DDlMonth2.SelectedValue+"' ");
    if (ds1.Tables[0].Rows.Count > 0)
    {
        aobj.ins("update tbl_ProfessionalTax set FromRs='"+Convert.ToDouble(txtFrom.Text)+"', ToRs='"+Convert.ToDouble(txtTo.Text)+"', TaxRs='"+Convert.ToDouble(txtTotalPT)+"' where Id='"+ds1.Tables[0].Rows[0]["Id"].ToString()+"'");

        lblPT.Text = "Data Already Exits for Year '" + ddlyear0.SelectedValue + "' And Now Successfully Updated FromMonth='" + DDlMonth1.SelectedValue + "' AND ToMonth='" + DDlMonth2.SelectedValue + "'";
        lblPT.Visible = true;
        return;
    }
    else
    {

        try
        {
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "ProfessionalTax";
            cmd.Parameters.AddWithValue("@FromRs", txtFrom.Text);
            cmd.Parameters.AddWithValue("@ToRs", txtTo.Text);
            cmd.Parameters.AddWithValue("@TaxRs", txtTotalPT.Text);
            cmd.Parameters.AddWithValue("@AcademicYear", ddlyear0.SelectedValue);



            cmd.ExecuteNonQuery();

            lblPT.Text = "Staff ProfessionalTax Inserted Successfully";
            lblPT.Visible = true;
            fillgrid();
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        catch (Exception)
        {
            lblPT.Text = "Problem with Database";
            lblPT.Visible = true;
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        finally
        {
            conn.Close();
        }
    }
    }
    
    protected void Button3_Click(object sender, EventArgs e)
    {
        ds1.Clear();
        ds1 = aobj.sel("select id,AcademicYear from tbl_IncomeTax where AcademicYear='" + ddlyear1.SelectedValue + "' AND FromDate='"+DDlMonth3.SelectedValue+"' And ToDate='"+DDlMonth4.SelectedValue+"'");
    if (ds1.Tables[0].Rows.Count > 0)
    {
        aobj.ins("update tbl_IncomeTax set FromRs='" + Convert.ToDouble(txtFrom.Text) + "', ToRs='" + Convert.ToDouble(txtTo.Text) + "', TaxRs='" + Convert.ToDouble(txtTotalPT) + "' where id='" + ds1.Tables[0].Rows[0]["id"].ToString() + "'");


        Label3.Text = "Data Already Exits for Year '" + ddlyear1.SelectedValue + "'";
        Label3.Visible = true;
        return;
    }
    else
    {
        try
        {
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spIncomeTax";
            cmd.Parameters.AddWithValue("@FromRs", txtFromIT.Text);
            cmd.Parameters.AddWithValue("@ToRs", txtToIT.Text);
            cmd.Parameters.AddWithValue("@TaxRs", txtToIT.Text);
            cmd.Parameters.AddWithValue("@AcademicYear", ddlyear1.SelectedValue);



            cmd.ExecuteNonQuery();

            Label3.Text = "Staff IncomeTax Inserted Successfully";
            Label3.Visible = true;
            gridIT();
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        catch (Exception)
        {
            Label3.Text = "Problem with Database";
            Label3.Visible = true;
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Inserted Successfully');", true);
        }
        finally
        {
            conn.Close();
        }
    }
    }
    void gridIT()
    {

        da = new SqlDataAdapter("select * from tbl_IncomeTax", conn);

        DataTable dt = new DataTable();
        da.Fill(dt);

        GridView3.DataSource = dt;
        GridView3.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //GridView1.EditIndex = e.NewEditIndex;

        
        ////GridView1.EditIndex = e.NewEditIndex;
        //int index = GridView1.EditIndex;
        //GridViewRow row = GridView1.Rows[index];
        //int id = Convert.ToInt16(GridView1.DataKeys[row.RowIndex].Value.ToString());
        ///*DropDownList quali = (DropDownList)GridView1.Rows[e.NewEditIndex].Cells[5].Controls[0];
        //SqlDataAdapter da = new SqlDataAdapter("Select QualificationId,QualificationName from tblQualificationMaster", cn);
       
        //*/
        //fillgrid();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        //GridView1.EditIndex =-1;
        //fillgrid();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
       

    }
    protected void DDlMonth0_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(DDlMonth0.SelectedIndex < DDlMonth.SelectedIndex)
        {
            DDlMonth.SelectedIndex = 0;
            DDlMonth0.SelectedIndex = 0;
        }

    }
    protected void DDlMonth3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DDlMonth2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DDlMonth2.SelectedIndex < DDlMonth.SelectedIndex)
        {
            DDlMonth1.SelectedIndex = 0;
            DDlMonth2.SelectedIndex = 0;
        }

    }
    protected void DDlMonth4_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DDlMonth4.SelectedIndex < DDlMonth.SelectedIndex)
        {
            DDlMonth3.SelectedIndex = 0;
            DDlMonth4.SelectedIndex = 0;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        fillgrid();
    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        fillpt();

    }
    protected void GridView3_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView3.PageIndex = e.NewPageIndex;
        fillit();
    }
}

