﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AccountantPanel_Accountant : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["new"] != null)
            {
                Label1.Visible = true;
                Label1.Text = Session["new"].ToString();
            }
            else
            {
                Response.Redirect("../Login.aspx");
            }
        }

        catch (Exception)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('Please Relogin Problem In Internet Connection');", true);
            Response.Redirect("../Login.aspx");

        }
    }
}
